package com.alfy.downloader

import org.json.JSONObject
import kotlinx.coroutines.flow.update
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * v1.25: alat pemindai tambahan untuk situs non-YouTube.
 *  OpenGraph (UA bot) | JS Deep | Iframe | Situs API | Redirect | Manifest
 * Semua fungsi mengembalikan null bila berhasil, selain itu alasan gagal (tampil di log alat).
 */
object MoreTools {
    private const val MAX = 1_500_000
    private const val UA_FB = "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)"
    private const val UA_TW = "Twitterbot/1.0"
    private const val UA_GB = "Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"
    private const val UA_DESK = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

    private val ic = RegexOption.IGNORE_CASE
    private val urlRe = Regex("https?://[^\\s\"'<>\\\\)]+")
    private val extRe = Regex("\\.(?:mp4|mpd|webm|mkv|mp3|m4a|aac|ogg|opus|mov|m4v|flv)(?:[?#]|$)|\\.m3u8?(?:[?#/&;=]|$)|[?&](?:format|type|ext|f)=m3u8", ic)
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads", ic)
    /** WebView Pro: domain iklan membandel (blacklist paksa, termasuk subdomain). */
    private val proBlockRe = Regex("(^|[./@])(bkcdn\\.net|nereserv\\.com)([:/?#]|$)", ic)
    private fun proBlocked(u: String): Boolean = proBlockRe.containsMatchIn(u) || u.contains("bkcdn.net", true) || u.contains("nereserv.com", true)
    private val metaRe = Regex("<meta\\b[^>]*>", ic)
    private val metaKeyRe = Regex("(?:property|name)\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val metaValRe = Regex("content\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val ldRe = Regex("\"(?:contentUrl|embedUrl|contentURL|audio|url)\"\\s*:\\s*\"(https?:[^\"]+)\"", ic)
    private val tagRe = Regex("<(?:source|video|audio)\\b[^>]*?\\b(?:src|data-src)\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val keyRe = Regex("[\"']?(?:file|src|source|video_url|videoUrl|hls|hlsUrl|hls_url|mp4|stream|streamUrl|download_url|downloadUrl|contentUrl|playbackUrl|manifest)[\"']?\\s*[:=]\\s*[\"'](https?://[^\"'\\s<>]+|/[^\"'\\s<>]+)[\"']", ic)
    private val scriptRe = Regex("<script\\b[^>]*?\\bsrc\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val iframeRe = Regex("<iframe\\b[^>]*?\\b(?:src|data-src)\\s*=\\s*[\"']([^\"']+)[\"']", ic)
    private val atobRe = Regex("atob\\(\\s*[\"']([A-Za-z0-9+/=]{16,})[\"']\\s*\\)")
    private val titleRe = Regex("<title[^>]*>([^<]{1,200})</title>", ic)
    private val skipJs = Regex("google-analytics|googletagmanager|gtag|facebook\\.net|doubleclick|jquery|bootstrap|fontawesome|cloudflareinsights|recaptcha|adsbygoogle|disqus|analytics", ic)

    private fun norm(s: String) = s.replace("\\/", "/").replace("\\u002F", "/", true).replace("\\u0026", "&", true)
        .replace("\\u0025", "%", true).replace("\\x2F", "/", true).replace("&amp;", "&")

    private fun get(u: String, ua: String, ref: String? = null, to: Int = 8000): String? = try {
        val k = URL(u).openConnection() as HttpURLConnection
        k.connectTimeout = to; k.readTimeout = to; k.instanceFollowRedirects = true
        k.setRequestProperty("User-Agent", ua)
        k.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8")
        k.setRequestProperty("Accept-Language", "en-US,en;q=0.9,id;q=0.8")
        (Resolver.vidlyxRef(u, ref) ?: ref)?.let { k.setRequestProperty("Referer", it) }
        try { Resolver.webCookie(u, ref)?.let { k.setRequestProperty("Cookie", it) } } catch (e: Throwable) { }
        val code = k.responseCode
        val st = if (code >= 400) k.errorStream else k.inputStream
        if (st == null) "" else {
            val buf = ByteArray(MAX); var n = 0
            st.use { s -> while (n < MAX) { val r = s.read(buf, n, MAX - n); if (r < 0) break; n += r } }
            String(buf, 0, n, Charsets.UTF_8)
        }
    } catch (e: Throwable) { null }

    private fun abs(base: String, u: String): String? = try {
        val x = norm(u.trim())
        if (x.startsWith("//")) "https:$x" else if (x.startsWith("http")) x else URL(URL(base), x).toString()
    } catch (e: Throwable) { null }

    private fun titleOf(html: String): String {
        for (m in metaRe.findAll(html)) {
            val t = m.value
            if (metaKeyRe.find(t)?.groupValues?.get(1)?.lowercase() == "og:title") return metaValRe.find(t)?.groupValues?.get(1)?.take(120) ?: ""
        }
        return titleRe.find(html)?.groupValues?.get(1)?.trim()?.take(120) ?: ""
    }

    /** Kumpulkan link media dari teks: meta og/twitter, JSON-LD, tag source/video/audio, kunci file/hls, dan URL berekstensi media. */
    private fun harvest(base: String, text0: String, meta: Boolean): LinkedHashSet<String> {
        val out = LinkedHashSet<String>()
        val texts = arrayListOf(text0)
        for (m in atobRe.findAll(text0)) {
            try { texts.add(String(android.util.Base64.decode(m.groupValues[1], android.util.Base64.DEFAULT), Charsets.UTF_8)) } catch (e: Throwable) { }
        }
        for (t0 in texts) {
            val t = norm(t0)
            if (meta) {
                for (m in metaRe.findAll(t)) {
                    val k = metaKeyRe.find(m.value)?.groupValues?.get(1)?.lowercase() ?: continue
                    if (k.startsWith("og:video") || k.startsWith("og:audio") || k == "twitter:player:stream") {
                        val x = abs(base, metaValRe.find(m.value)?.groupValues?.get(1) ?: continue) ?: continue
                        if (!adRe.containsMatchIn(x)) out.add(x)
                    }
                }
                for (m in ldRe.findAll(t)) { val x = m.groupValues[1]; if (extRe.containsMatchIn(x) && !adRe.containsMatchIn(x)) out.add(x) }
            }
            for (m in tagRe.findAll(t)) { val x = abs(base, m.groupValues[1]) ?: continue; if (!adRe.containsMatchIn(x)) out.add(x) }
            for (m in keyRe.findAll(t)) { val x = abs(base, m.groupValues[1]) ?: continue; if (extRe.containsMatchIn(x) && !adRe.containsMatchIn(x)) out.add(x) }
            for (m in urlRe.findAll(t)) { val x = m.value.trimEnd('.', ',', ';', ')'); if (extRe.containsMatchIn(x) && !adRe.containsMatchIn(x)) out.add(x) }
        }
        out.remove(base)
        return out
    }

    private fun emit(name: String, c: Collection<String>, ref: String?, title: String, refMap: Map<String, String>? = null, img: String = ""): Int {
        val ok = AtomicInteger(0)
        val ths = c.take(12).map { x ->
            Thread {
                ToolLog.tl.set(name)
                try { if (Resolver.addMediaChecked(x, refMap?.get(x) ?: ref, title, extRe.containsMatchIn(x))) ok.incrementAndGet() } catch (e: Throwable) { }
                finally { ToolLog.tl.remove() }
            }.apply { isDaemon = true; start() }
        }
        val joinEnd = System.currentTimeMillis() + 6_000   // total (bukan per thread) agar tidak melewati batas scan
        ths.forEach { try { it.join(maxOf(1L, joinEnd - System.currentTimeMillis())) } catch (e: Exception) { } }
        if (img.startsWith("http") && ok.get() > 0) {   // thumbnail dari JSON API -> cover musik
            val set = c.toSet()
            Repo.detected.update { l -> l.map { d -> if (d.img.isEmpty() && (d.url in set || d.previewUrl in set)) d.copy(img = img) else d } }
        }
        return ok.get()
    }

    /** OpenGraph: meta og:video / twitter:player:stream / JSON-LD, dibaca dengan UA crawler (Facebook, Twitter, Google) agar situs memberi data lengkap. */
    fun openGraph(page: String): String? {
        var got = 0; var tried = 0
        for (ua in listOf(UA_FB, UA_TW, UA_GB, UA_DESK)) {
            val html = get(page, ua) ?: continue
            tried++
            val c = harvest(page, html, true)
            if (c.isNotEmpty() && emit("OpenGraph", c, page, titleOf(html)) > 0) { got++; break }
        }
        return if (got > 0) null else if (tried == 0) "halaman tidak terbuka" else "tanpa og:video ($tried UA dicoba)"
    }

    /** JS Deep: unduh file JavaScript milik halaman (maks 10) dan cari link media/manifest di dalamnya. */
    fun jsDeep(page: String): String? {
        val html = get(page, Resolver.UA) ?: return "halaman tidak terbuka"
        val srcs = scriptRe.findAll(html).mapNotNull { abs(page, it.groupValues[1]) }.filter { !skipJs.containsMatchIn(it) }.distinct().take(10).toList()
        val found = LinkedHashSet<String>()
        found.addAll(harvest(page, html, false))
        val deadline = System.currentTimeMillis() + 7_000
        for (s in srcs) {
            if (System.currentTimeMillis() > deadline || found.size >= 12) break
            val js = get(s, Resolver.UA, page, 6000) ?: continue
            found.addAll(harvest(s, js, false))
        }
        if (found.isEmpty()) return "tanpa link di ${srcs.size} file JS"
        return if (emit("JS Deep", found, page, titleOf(html)) > 0) null else "${found.size} kandidat ditolak"
    }

    /** Iframe: telusuri iframe (kedalaman 5) lalu baca isi pemutar yang tertanam; WebView tersembunyi + JS sniffer (video/m3u8/mp4) jalan paralel. */
    fun iframe(page: String): String? {
        val seenU = LinkedHashSet<String>(); seenU.add(page)
        val q = ArrayDeque<Triple<String, String, Int>>()
        val first = get(page, Resolver.UA) ?: ""   // Cloudflare bisa menolak HTTP biasa; WebView tersembunyi tetap jalan
        val found = LinkedHashSet<String>(); var title = titleOf(first); var refFound = page
        val jq = ConcurrentLinkedQueue<Pair<String, String>>()
        val refMap = java.util.concurrent.ConcurrentHashMap<String, String>()
        val wvUaConst = Resolver.UA
        val mh = Handler(Looper.getMainLooper())
        var iw: WebView? = null
        val capTitle = java.util.concurrent.atomic.AtomicReference<String?>(null)   // v1.189: document.title saat .m3u8 ketemu
        mh.post {
            try {
                val w = WebView(Repo.app); iw = w
                w.settings.javaScriptEnabled = true; w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                w.settings.setSupportMultipleWindows(false); w.settings.javaScriptCanOpenWindowsAutomatically = false
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                w.addJavascriptInterface(Bridge(jq, page), "AlfyJ")
                w.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { view.evaluateJavascript(hookJs, null) }
                    override fun onPageFinished(view: WebView, url: String) { try { android.webkit.CookieManager.getInstance().flush() } catch (e: Throwable) { }; view.evaluateJavascript(hookJs, null); view.evaluateJavascript(iframeSniffJs, null); view.evaluateJavascript(JW_PROBE_JS, null) }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (proBlocked(u) && !request.isForMainFrame) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                        if (!request.isForMainFrame && WebTool.isAd(u, page)) return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))   // v1.134
                        if (adRe.containsMatchIn(u) || request.isForMainFrame || Resolver.isGv(u)) return null
                        val ext = Resolver.extOf(u)
                        if (ext == "ts" || ext == "m4s") return null
                        if (u.contains(".m3u8", true)) {
                            try { android.webkit.CookieManager.getInstance().flush() } catch (e: Throwable) { }
                            val ck0 = try { android.webkit.CookieManager.getInstance().getCookie(u) } catch (e: Throwable) { null }
                            Resolver.noteHls(u, request.requestHeaders?.get("Referer") ?: page, wvUaConst, ck0)
                            if (capTitle.get() == null) mh.post { try { view.evaluateJavascript(TITLE_JS) { r -> val c = cleanTitle(r); if (c.isNotBlank()) capTitle.compareAndSet(null, c) } } catch (e: Throwable) { } }
                        }
                        if (WebTool.looksMedia(u, request) || (cdnHintRe.containsMatchIn(u) && ext !in noExt)) jq.add(Pair(u, request.requestHeaders?.get("Referer") ?: page))
                        return null
                    }
                }
                w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        try {
        fun scan(u: String, html: String, d: Int) {
            val h = harvest(u, html, true)
            if (h.isNotEmpty() && found.isEmpty()) refFound = u
            found.addAll(h)
            if (d < 5) for (m in iframeRe.findAll(html)) {
                val x = abs(u, m.groupValues[1]) ?: continue
                if (x.startsWith("http") && !adRe.containsMatchIn(x) && seenU.add(x) && q.size < 10) q.add(Triple(x, u, d + 1))
            }
        }
        scan(page, first, 0)
        var n = 0
        val deadline = System.currentTimeMillis() + 6_000   // anggaran total scan 10 dtk: crawl HTML dibatasi 6 dtk
        while (q.isNotEmpty() && n < 10 && found.size < 12 && System.currentTimeMillis() < deadline) {
            val (u, r, d) = q.removeFirst()
            val h = get(u, Resolver.UA, r) ?: continue
            n++
            if (title.isBlank()) title = titleOf(h)
            scan(u, h, d)
        }
        // JS sniffer: bila crawl HTML kosong, beri WebView waktu singkat menangkap <video>/.m3u8/.mp4 dari iframe
        var w = 0
        var jumpedF = false
        while (found.isEmpty() && jq.isEmpty() && w < ScanLimit.cap(8_000)) {
            if (w % 1000 == 0 && w > 0) mh.post { try { iw?.evaluateJavascript(iframeSniffJs, null); iw?.evaluateJavascript(JW_PROBE_JS, null) } catch (e: Throwable) { } }
            // jalur tambahan: iframe lintas-origin tidak bisa dibaca dari halaman induk -> buka iframe pemutar sebagai halaman utama (Referer = halaman asal) agar player probe JWPlayer & sadap jaringan berjalan di dalamnya
            if (!jumpedF && w >= 3000) {
                jumpedF = true
                val cand = seenU.firstOrNull { it != page && it.startsWith("http") && !adRe.containsMatchIn(it) && !proBlocked(it) && !WebTool.isAd(it, page) && (Regex("embed|player|/e/|/v/|jw|vid", ic).containsMatchIn(it)) } ?: seenU.firstOrNull { it != page && it.startsWith("http") && !adRe.containsMatchIn(it) && !proBlocked(it) && !WebTool.isAd(it, page) }
                if (cand != null) mh.post { try { iw?.loadUrl(cand, mapOf("Referer" to page)) } catch (e: Throwable) { } }
            }
            try { Thread.sleep(250) } catch (e: InterruptedException) { break }
            w += 250
        }
        var jv = jq.poll()
        while (jv != null) { val ju = jv.first; if (found.size < 12 && !proBlocked(ju) && !adRe.containsMatchIn(ju)) { if (found.isEmpty()) refFound = page; found.add(ju); refMap.putIfAbsent(ju, jv.second) }; jv = jq.poll() }
        if (found.isEmpty()) return if (first.isEmpty()) "halaman tidak terbuka" else "tanpa media di $n iframe"
        // Iframe: judul halaman + cookie + User-Agent dari WebView, dilampirkan ke m3u8 (sama seperti HLS Sniffer)
        val wvInfo = arrayOfNulls<String>(2)
        val latch = java.util.concurrent.CountDownLatch(1)
        mh.post { try { wvInfo[0] = iw?.title; wvInfo[1] = iw?.settings?.userAgentString; if (capTitle.get() == null) iw?.evaluateJavascript(TITLE_JS) { r -> val c = cleanTitle(r); if (c.isNotBlank()) capTitle.compareAndSet(null, c) } } catch (e: Throwable) { } finally { latch.countDown() } }
        try { latch.await(1500, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
        val wvTitle = wvInfo[0]?.trim()?.take(120)?.replace(Regex("[\\\\/:*?\"<>|]"), " ")?.trim().orEmpty()
        if (wvTitle.isNotBlank() && !wvTitle.startsWith("http", true)) title = wvTitle
        try { Thread.sleep(150) } catch (e: InterruptedException) { }
        capTitle.get()?.takeIf { it.isNotBlank() }?.let { title = it }   // judul asli halaman saat m3u8 tertangkap (bukan "host convert")
        val wvUa = wvInfo[1]?.takeIf { it.isNotBlank() } ?: Resolver.UA
        try { android.webkit.CookieManager.getInstance().flush() } catch (e: Throwable) { }
        for (x in found) if (x.contains(".m3u8", true)) {
            val ck = try { android.webkit.CookieManager.getInstance().getCookie(x)?.takeIf { it.isNotBlank() } ?: android.webkit.CookieManager.getInstance().getCookie(refFound) } catch (e: Throwable) { null }
            Resolver.noteHls(x, refMap[x] ?: refFound, wvUa, ck)
        }
        return if (emit("Iframe", found, refFound, title, refMap) > 0) null else "${found.size} kandidat ditolak"
        } finally { mh.post { WvClean.kill(iw); iw = null } }
    }

    private const val TITLE_JS = "(function(){try{return document.title||'';}catch(e){return '';}})()"
    private fun cleanTitle(r: String?): String {
        val t = (r ?: "").trim().trim('"').replace("\\u0026", "&").replace("\\\"", "\"").replace("\\/", "/")
        val c = t.take(120).replace(Regex("[\\\\/:*?\"<>|]"), " ").trim()
        return if (c.startsWith("http", true) || c.equals("null", true)) "" else c
    }

    /** Iframe: JS mirip VideoSniffer - sapu <video>/<audio>/<source> + link .m3u8/.mp4 di dokumen dan iframe sealamat (sampai level 5), lalu coba putar. */
    private val iframeSniffJs = """(function(){function rep(u){try{if(u&&typeof u==='string'&&u.indexOf('http')===0)AlfyJ.r(u);}catch(e){}}
function sweep(d,l){try{d.querySelectorAll('video,audio,source').forEach(function(v){rep(v.currentSrc);rep(v.src);try{v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}catch(e){}});
var m=d.documentElement.innerHTML.split('\\/').join('/').match(/https?:\/\/[^"'\s<>\\]+\.(?:m3u8|mp4|webm|mpd)[^"'\s<>\\]*/g);if(m)m.forEach(rep);
if(l<5)d.querySelectorAll('iframe').forEach(function(f){try{if(f.hasAttribute('sandbox')&&!f.__af){f.__af=1;var s=f.src;f.removeAttribute('sandbox');if(s)f.src=s;}}catch(e){}try{var u=f.src||f.getAttribute('data-src');if(u&&/\.(m3u8|mp4|webm|mpd)(\?|$)/i.test(u))rep(u);}catch(e){}try{var x=f.contentDocument;if(x)sweep(x,l+1);}catch(e){}});}catch(e){}}
sweep(document,0);})();"""

    /** Manifest: cari file .m3u8/.mpd/.mp4 lewat tebakan pola umum pemutar (config JSON, playlist, /hls/, /stream/). */
    fun manifest(page: String): String? {
        val html = get(page, UA_DESK) ?: return "halaman tidak terbuka"
        val found = LinkedHashSet<String>()
        val nh = norm(html).replace("&amp;", "&").replace("\\x26", "&").replace("%3Dm3u8", "=m3u8")
        // 1) URL berkutip, toleran token/IP/parameter dinamis (panjang sampai 1000 karakter)
        for (m in Regex("[\"'`(]([^\"'`\\s<>()]{2,600}\\.(?:m3u8|mpd)(?:[?#/][^\"'`\\s<>()]{0,600})?)[\"'`)]", ic).findAll(nh)) {
            val x = abs(page, m.groupValues[1]) ?: continue
            if (!adRe.containsMatchIn(x)) found.add(x)
        }
        // 2) URL tanpa kutip (halaman berantakan / teks polos / atribut tanpa kutip)
        for (m in Regex("https?://[^\\s\"'`<>\\\\]{2,800}?\\.m3u8(?:[?#][^\\s\"'`<>\\\\]{0,800})?", ic).findAll(nh)) {
            val x = m.value.trimEnd(',', ';', ')', ']', '}', '.')
            if (!adRe.containsMatchIn(x)) found.add(x)
        }
        // 3) URL relatif/protokol-relatif yang menyebut m3u8 di tengah teks
        for (m in Regex("(?<![A-Za-z0-9:])(//[A-Za-z0-9.\\-]+/[^\\s\"'`<>\\\\]{2,600}?\\.m3u8(?:[?#][^\\s\"'`<>\\\\]{0,600})?)", ic).findAll(nh)) {
            val x = abs(page, m.groupValues[1]) ?: continue
            if (!adRe.containsMatchIn(x)) found.add(x)
        }
        // endpoint JSON/XML kecil yang disebut halaman (config/playlist/source) -> baca isinya
        val eps = Regex("[\"'](https?://[^\"'\\s]+(?:config|playlist|sources?|player|manifest|info)[^\"'\\s]*\\.(?:json|xml)[^\"'\\s]*|/[^\"'\\s]*(?:config|playlist|sources?|manifest)[^\"'\\s]*\\.(?:json|xml)[^\"'\\s]*)[\"']", ic)
            .findAll(norm(html)).mapNotNull { abs(page, it.groupValues[1]) }.distinct().take(4).toList()
        val mDeadline = System.currentTimeMillis() + 7_000
        for (e in eps) { if (System.currentTimeMillis() > mDeadline) break; val t = get(e, Resolver.UA, Resolver.vidlyxRef(page) ?: page, 6000) ?: continue; found.addAll(harvest(e, t, false)) }
        if (found.isEmpty()) return "tanpa manifest/playlist"
        return if (emit("Manifest", found, Resolver.vidlyxRef(page) ?: page, titleOf(html)) > 0) null else "${found.size} kandidat ditolak"
    }

    /** Redirect: ikuti tautan pendek/redirect sampai tujuan akhir; bila media langsung diambil, bila halaman baru dipindai. */
    fun redirect(page: String): String? {
        val k = try { URL(page).openConnection() as HttpURLConnection } catch (e: Throwable) { return "URL tidak valid" }
        var fin = page; var ct = ""
        try {
            k.connectTimeout = 7000; k.readTimeout = 7000; k.instanceFollowRedirects = true
            k.setRequestProperty("User-Agent", Resolver.UA)
            k.responseCode
            fin = k.url.toString(); ct = (k.contentType ?: "").lowercase()
            try { k.inputStream?.close() } catch (e: Throwable) { }
        } catch (e: Throwable) { return "tidak ada redirect (${(e.message ?: "gagal").take(40)})" }
        if (ct.startsWith("video/") || ct.startsWith("audio/") || ct.contains("mpegurl") || ct.contains("dash+xml"))
            return if (emit("Redirect", listOf(fin), page, "") > 0) null else "tujuan media ditolak"
        if (fin.contains("/login", true) || fin.contains("/checkpoint", true)) return "redirect ke halaman login"
        if (fin == page || fin.substringBefore('#').trimEnd('/') == page.substringBefore('#').trimEnd('/')) return "tanpa redirect"
        Resolver.submit(fin, page, true, "Redirect")
        return null
    }

    private fun jstr(o: JSONObject?, k: String): String = o?.optString(k, "") ?: ""

    /** Situs API: Vimeo, Dailymotion, Reddit, Streamable, TikTok, Facebook, Imgur (gifv). */
    fun siteApi(page: String): String? {
        val host = (try { android.net.Uri.parse(page).host ?: "" } catch (e: Throwable) { "" }).lowercase().removePrefix("www.")
        val urls = LinkedHashSet<String>(); var title = ""; var ref: String? = page; var thumb = ""
        when {
            host.endsWith("vimeo.com") -> {
                val id = Regex("(\\d{6,12})").find(android.net.Uri.parse(page).path ?: "")?.groupValues?.get(1) ?: return "ID Vimeo tidak ditemukan"
                val j = JSONObject(get("https://player.vimeo.com/video/$id/config", UA_DESK, "https://vimeo.com/") ?: return "Vimeo tidak terbuka")
                title = jstr(j.optJSONObject("video"), "title")
                thumb = j.optJSONObject("video")?.optJSONObject("thumbs")?.let { t -> t.optString("1280", t.optString("960", t.optString("base", ""))) } ?: ""
                val f = j.optJSONObject("request")?.optJSONObject("files")
                val pr = f?.optJSONArray("progressive")
                if (pr != null) for (i in 0 until pr.length()) { val u = jstr(pr.optJSONObject(i), "url"); if (u.startsWith("http")) urls.add(u) }
                val cdns = f?.optJSONObject("hls")?.optJSONObject("cdns")
                if (cdns != null) for (n in cdns.keys()) { val u = jstr(cdns.optJSONObject(n), "url"); if (u.startsWith("http")) { urls.add(u); break } }
                ref = "https://vimeo.com/"
            }
            host == "dailymotion.com" || host == "dai.ly" -> {
                val id = Regex("(?:video/|dai\\.ly/)([a-zA-Z0-9]+)").find(page)?.groupValues?.get(1) ?: return "ID Dailymotion tidak ditemukan"
                val j = JSONObject(get("https://www.dailymotion.com/player/metadata/video/$id", UA_DESK, "https://www.dailymotion.com/") ?: return "Dailymotion tidak terbuka")
                title = j.optString("title", "")
                val q = j.optJSONObject("qualities")
                if (q != null) for (n in q.keys()) { val a = q.optJSONArray(n) ?: continue
                    for (i in 0 until a.length()) { val u = jstr(a.optJSONObject(i), "url"); if (u.startsWith("http")) urls.add(u) } }
            }
            host.endsWith("reddit.com") || host == "redd.it" -> {
                val base = page.substringBefore('?').substringBefore('#').trimEnd('/')
                val t = get("$base.json?raw_json=1", Resolver.UA, "https://www.reddit.com/") ?: return "Reddit tidak terbuka"
                val d = JSONObject("{\"a\":" + t.trim() + "}").optJSONArray("a")?.optJSONObject(0)?.optJSONObject("data")?.optJSONArray("children")?.optJSONObject(0)?.optJSONObject("data") ?: return "Reddit: post tidak terbaca"
                title = d.optString("title", "")
                thumb = d.optString("thumbnail", "").takeIf { it.startsWith("http") }
                    ?: d.optJSONObject("preview")?.optJSONArray("images")?.optJSONObject(0)?.optJSONObject("source")?.optString("url", "")?.replace("&amp;", "&") ?: ""
                val cp = d.optJSONArray("crosspost_parent_list")?.optJSONObject(0)
                for (src in listOf(d, cp)) {
                    val rv = src?.optJSONObject("secure_media")?.optJSONObject("reddit_video") ?: src?.optJSONObject("media")?.optJSONObject("reddit_video") ?: continue
                    for (k in listOf("hls_url", "fallback_url", "dash_url")) { val u = rv.optString(k, ""); if (u.startsWith("http")) urls.add(u) }
                }
                val ov = d.optJSONObject("preview")?.optJSONObject("reddit_video_preview")?.optString("fallback_url", "") ?: ""
                if (ov.startsWith("http")) urls.add(ov)
                ref = "https://www.reddit.com/"
            }
            host == "streamable.com" -> {
                val code = Regex("streamable\\.com/(?:[a-z]/)?([a-z0-9]+)").find(page)?.groupValues?.get(1) ?: return "kode Streamable tidak ditemukan"
                val j = JSONObject(get("https://api.streamable.com/videos/$code", UA_DESK) ?: return "Streamable tidak terbuka")
                title = j.optString("title", "")
                thumb = j.optString("thumbnail_url", "").let { if (it.startsWith("//")) "https:$it" else it }
                val f = j.optJSONObject("files")
                if (f != null) for (n in f.keys()) { val u = jstr(f.optJSONObject(n), "url"); if (u.isNotEmpty()) urls.add(if (u.startsWith("//")) "https:$u" else u) }
            }
            host.endsWith("tiktok.com") -> {
                val j = JSONObject(get("https://www.tikwm.com/api/?hd=1&url=" + URLEncoder.encode(page, "UTF-8"), UA_DESK, "https://www.tikwm.com/") ?: return "TikTok API tidak terbuka")
                val d = j.optJSONObject("data") ?: return "TikTok API: " + j.optString("msg", "tanpa data").take(50)
                title = d.optString("title", "")
                thumb = listOf("origin_cover", "cover", "ai_dynamic_cover").firstNotNullOfOrNull { k -> d.optString(k, "").takeIf { it.isNotEmpty() }?.let { abs("https://www.tikwm.com/", it) } } ?: ""
                for (k in listOf("hdplay", "play", "wmplay", "music")) { val u = d.optString(k, ""); if (u.isNotEmpty()) urls.add(abs("https://www.tikwm.com/", u) ?: continue) }
                ref = null
            }
            host.endsWith("facebook.com") || host == "fb.watch" || host.endsWith("fb.com") -> {
                val fbRe = Regex("\"(?:browser_native_hd_url|browser_native_sd_url|playable_url_quality_hd|playable_url|hd_src_no_ratelimit|sd_src_no_ratelimit|hd_src|sd_src)\"\\s*:\\s*\"(https?:[^\"]+)\"")
                val h = get(page, UA_DESK)
                if (h != null) {
                    for (m in fbRe.findAll(h)) urls.add(norm(m.groupValues[1]))
                    title = titleOf(h)
                }
                if (urls.isEmpty()) {
                    val h2 = get("https://www.facebook.com/plugins/video.php?href=" + URLEncoder.encode(page, "UTF-8"), UA_DESK, "https://www.facebook.com/")
                    if (h2 != null) {
                        for (m in fbRe.findAll(h2)) urls.add(norm(m.groupValues[1]))
                        if (title.isBlank()) title = titleOf(h2)
                    }
                    if (h == null && h2 == null) return "Facebook tidak terbuka"
                }
            }
            host == "imgur.com" || host == "i.imgur.com" -> {
                if (page.contains(".gifv", true)) urls.add(page.substringBefore('?').replace(".gifv", ".mp4", true)) else return "bukan gifv"
            }
            else -> return "situs tidak punya API khusus"
        }
        if (urls.isEmpty()) return "API tanpa link media"
        return if (emit("Situs API", urls, ref, title, null, thumb) > 0) null else "${urls.size} link API ditolak"
    }
    private val cdnHintRe = Regex("mime_type=(?:video|audio)|mime=(?:video|audio)|/video/tos/|/aweme/|bytevc|\\.m3u8|\\.mpd|\\.mp4|\\.webm|\\.m4a|\\.mp3|master\\.m3u8|playlist\\.m3u8", ic)
    private val noExt = setOf("js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "woff", "woff2", "ttf", "html", "htm", "map", "json", "ts", "m4s", "txt", "xml")

    private val hookJs = """(function(){if(window.__aw)return;window.__aw=1;
function rep(u){try{if(u&&typeof u==='string'&&u.indexOf('blob:')!==0&&u.indexOf('data:')!==0)AlfyJ.r(u);}catch(e){}}
function scan(t){try{var m=String(t).split('\\/').join('/').match(/https?:\/\/[^"'\s<>\\]+\.(?:mp4|m3u8|mpd|webm|m4a|mp3)[^"'\s<>\\]*/g);if(m)m.forEach(rep);}catch(e){}}
var of=window.fetch;if(of)window.fetch=function(a){try{var fu=typeof a==='string'?a:(a&&a.url);if(fu&&/\.(?:mp4|m3u8|mpd|webm|m4a|mp3)(?:[?#]|$)/i.test(String(fu)))rep(fu);}catch(e){}var p=of.apply(this,arguments);try{p.then(function(r){try{var ct=r.headers.get('content-type')||'';if(/video|audio|mpegurl|dash/i.test(ct))rep(r.url);else if(/json|text/i.test(ct))r.clone().text().then(scan);}catch(e){}});}catch(e){}return p;};
var xo=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){var su=String(u);try{if(/\.(?:mp4|m3u8|mpd|webm|m4a|mp3)(?:[?#]|$)/i.test(su))rep(su);}catch(e){}this.addEventListener('load',function(){try{var ct=this.getResponseHeader('content-type')||'';if(/video|audio|mpegurl|dash/i.test(ct))rep(this.responseURL||su);else if(/json|text|xml/i.test(ct))scan(this.responseText);}catch(e){}});return xo.apply(this,arguments);};
try{var d=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'src');if(d&&d.set){Object.defineProperty(HTMLMediaElement.prototype,'src',{get:d.get,set:function(v){rep(String(v));return d.set.call(this,v);}});}}catch(e){}
try{var sa=Element.prototype.setAttribute;Element.prototype.setAttribute=function(n,v){try{if(n==='src'&&/^(VIDEO|AUDIO|SOURCE)$/.test(this.tagName))rep(String(v));}catch(e){}return sa.apply(this,arguments);};}catch(e){}
})();"""

    /** Player probe JWPlayer: baca playlist/sources lewat window.jwplayer (dokumen + iframe sealamat, maks 3 level) + event ready/play/playlistItem/levelsChanged. Polling terbatas (18x400 ms). Kandidat dikirim lewat AlfyJ.rr (URL absolut + referer frame). */
    internal const val JW_PROBE_JS = """(function(){if(window.__alfyJwp)return;window.__alfyJwp=1;var sent={},n=0,MAXN=18;
function abs(u,b){try{return new URL(u,b||location.href).href;}catch(e){return '';}}
function rep(u,b){try{if(!u||typeof u!=='string')return;u=abs(u,b);if(u.indexOf('http')!==0||sent[u])return;if(/\.(?:jpe?g|png|gif|webp|svg|ico|vtt|srt|css|js)(?:[?#]|$)/i.test(u))return;sent[u]=1;AlfyJ.rr(u,b||'');}catch(e){}}
function fromItem(it,b){if(!it)return;try{rep(it.file,b);}catch(e){}try{(it.sources||[]).forEach(function(s){if(s)rep(s.file,b);});}catch(e){}try{(it.allSources||[]).forEach(function(s){if(s)rep(s.file,b);});}catch(e){}}
function fromPlayer(p,b){try{var pl=p.getPlaylist&&p.getPlaylist();if(pl&&pl.forEach)pl.forEach(function(it){fromItem(it,b);});}catch(e){}try{if(p.getPlaylistItem)fromItem(p.getPlaylistItem(),b);}catch(e){}try{var c=p.getConfig&&p.getConfig();if(c){if(c.playlist&&c.playlist.forEach)c.playlist.forEach(function(it){fromItem(it,b);});fromItem(c,b);}}catch(e){}}
function hook(p,b){try{fromPlayer(p,b);if(p.__alfyH)return;p.__alfyH=1;['ready','play','playlistItem','levelsChanged'].forEach(function(ev){try{p.on(ev,function(){fromPlayer(p,b);});}catch(e){}});}catch(e){}}
function probe(w,d){try{var jw=w.jwplayer;if(typeof jw==='function'){var b=w.location.href;try{var p0=jw();if(p0&&p0.getPlaylist)hook(p0,b);}catch(e){}
try{w.document.querySelectorAll('.jwplayer,[id^=jwplayer]').forEach(function(el){try{if(!el.id)return;var p=jw(el.id);if(p&&p.getPlaylist)hook(p,b);}catch(e){}});}catch(e){}}}catch(e){}
if(d<3)try{var fr=w.document.querySelectorAll('iframe');for(var i=0;i<fr.length;i++){try{var cw=fr[i].contentWindow;if(cw&&cw.document)probe(cw,d+1);}catch(e){}}}catch(e){}}
function tick(){probe(window,0);if(++n<MAXN)setTimeout(tick,400);}
tick();})();"""

    /** v1.189: IntersectionObserver - <video> yang muncul di layar langsung dilaporkan (AlfyJ.r) & dipancing play, tanpa menunggu timer. */
    internal const val VIDEO_IO_JS = """(function(){if(window.__aio)return;window.__aio=1;
function seen(v){try{if(v.__aq)return;v.__aq=1;io.observe(v);}catch(e){}}
var io=new IntersectionObserver(function(es){es.forEach(function(en){if(!en.isIntersecting)return;var v=en.target;
 try{var u=v.currentSrc||v.src;if(u&&u.indexOf('http')===0)AlfyJ.r(u);}catch(e){}
 try{v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}catch(e){}
 try{(v.querySelectorAll?v.querySelectorAll('source'):[]).forEach(function(s){if(s.src&&s.src.indexOf('http')===0)AlfyJ.r(s.src);});}catch(e){}
 try{AlfyJ.v();}catch(e){}});},{threshold:0.4});
function all(){document.querySelectorAll('video').forEach(seen);}
try{new MutationObserver(all).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
all();})();"""

    private val actJs = """(function(){try{window.__ck=window.__ck||0;
document.querySelectorAll('video,audio').forEach(function(v){try{if(v.currentSrc)AlfyJ.r(v.currentSrc);if(v.src)AlfyJ.r(v.src);v.muted=true;var p=v.play();if(p&&p.catch)p.catch(function(){});}catch(e){}});
var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.vjs-big-play-button,.plyr__control--overlaid,.fp-play,.ytp-large-play-button,[class*=play-button],[class*=PlayButton],[aria-label*=Play],[aria-label*=Putar],button[title*=Play]');
if(b)b.click();
if(window.__ck++<2){var e=document.elementFromPoint(innerWidth/2,innerHeight/2);if(e&&e.click)e.click();}
window.scrollBy(0,150);}catch(e){}})();"""

    class Bridge(val q: ConcurrentLinkedQueue<Pair<String, String>>, val page: String) {
        @JavascriptInterface fun r(u: String) { if (u.startsWith("http") && q.size < 200 && !proBlocked(u) && !WebTool.isAd(u)) q.add(Pair(u, page)) }   // v1.134: URL iklan dibuang
        @JavascriptInterface fun rr(u: String, ref: String?) { if (u.startsWith("http") && q.size < 200 && !proBlocked(u) && !WebTool.isAd(u)) q.add(Pair(u, ref?.takeIf { it.startsWith("http") } ?: page)) }   // player probe JWPlayer: referer = alamat frame pemutar
        @JavascriptInterface fun v() { }   // v1.189: penanda video terlihat (link dilaporkan lewat r)
    }

    /** WebView Pro: WebView tersembunyi (UA ponsel) + pengait fetch/XHR/<video>.src + tekan play/scroll otomatis + sadap jaringan. Untuk CDN sulit & situs short-video. */
    fun webPro(page: String): String? {
        val q = ConcurrentLinkedQueue<Pair<String, String>>()
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val loaded = java.util.concurrent.atomic.AtomicBoolean(false)
        val jumped = java.util.concurrent.atomic.AtomicBoolean(false)   // v1.134: sudah pindah ke iframe pemutar
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                w.settings.setSupportMultipleWindows(false)
                w.settings.javaScriptCanOpenWindowsAutomatically = false
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                w.addJavascriptInterface(Bridge(q, page), "AlfyJ")
                w.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) { view.evaluateJavascript(hookJs, null) }
                    override fun onPageCommitVisible(view: WebView, url: String) { view.evaluateJavascript(hookJs, null); view.evaluateJavascript(VIDEO_IO_JS, null) }
                    override fun onPageFinished(view: WebView, url: String) { loaded.set(true); view.evaluateJavascript(hookJs, null); view.evaluateJavascript(VIDEO_IO_JS, null); view.evaluateJavascript(actJs, null); view.evaluateJavascript(WebTool.IFRAME_JS, null) }
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame && (loaded.get() || WebTool.isAd(request.url.toString(), page))
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (proBlocked(u) && !request.isForMainFrame) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                        // v1.134: URL iklan (daftar blokir) tidak dimuat & tidak ditangkap
                        if (!request.isForMainFrame && WebTool.isAd(u, page)) return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                        if (adRe.containsMatchIn(u) || request.isForMainFrame || Resolver.isGv(u)) return null
                        val ext = Resolver.extOf(u)
                        if (ext == "ts" || ext == "m4s") return null
                        val rq = request.requestHeaders?.get("Referer") ?: page
                        if (u.contains(".m3u8", true)) {
                            try { android.webkit.CookieManager.getInstance().flush() } catch (e: Throwable) { }
                            val ck0 = try { android.webkit.CookieManager.getInstance().getCookie(u) } catch (e: Throwable) { null }
                            Resolver.noteHls(u, rq, Resolver.UA, ck0)
                        }
                        if (WebTool.looksMedia(u, request) || (cdnHintRe.containsMatchIn(u) && ext !in noExt)) q.add(Pair(u, rq))
                        return null
                    }
                }
                // AlfyExtras: pemantau pemutar (document-start). Hasilnya masuk antrean q yang sama (lewat uji addMediaChecked, maks 15). Gagal/tidak didukung -> diabaikan.
                try { com.alfy.downloader.extras.DocStartHook.install(w) { hu, _, _ -> if (!adRe.containsMatchIn(hu) && !proBlocked(hu) && !WebTool.isAd(hu, page)) q.add(Pair(hu, page)) } } catch (e: Throwable) { }
                w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        var waited = 0; var firstAt = -1; var found = 0
        val holdMs = if (Regex("facebook\\.com|fb\\.watch|fb\\.com|instagram\\.com", RegexOption.IGNORE_CASE).containsMatchIn(page)) 3500 else 2000
        val tried = HashSet<String>()
        val capMs = if (page.contains("vldey", true) || page.contains("vidlyx", true)) 15_000 else 10_000
        while (waited < ScanLimit.cap(capMs)) {
            if (waited % 1500 == 0 && waited >= 1500) h.post { try { wv?.evaluateJavascript(actJs, null) } catch (e: Throwable) { } }
            // v1.134: video di dalam Iframe: pancing play; bila belum ada link, buka src iframe terbesar (bukan iklan) sebagai halaman utama dengan Referer halaman asal
            if (waited % 1500 == 0 && waited >= 1500) h.post {
                WebTool.pokeIframe(wv, page) { s ->
                    if (found == 0 && waited >= 3000 && s != page && jumped.compareAndSet(false, true)) { try { wv?.loadUrl(s, mapOf("Referer" to page)) } catch (e: Throwable) { } }
                }
            }
            var qi = q.poll()
            while (qi != null) {
                val u = qi.first
                if (proBlocked(u) || WebTool.isAd(u, page)) { qi = q.poll(); continue }
                if (tried.size < 15 && tried.add(u)) {
                    ToolLog.tl.set("WebView Pro")
                    val ok = try { Resolver.addMediaChecked(u, qi.second, "", true) } catch (e: Throwable) { false }
                    ToolLog.tl.remove()
                    if (ok) { found++; if (firstAt < 0) firstAt = waited }
                }
                qi = q.poll()
            }
            if (firstAt >= 0 && waited - firstAt >= holdMs) break
            Thread.sleep(300); waited += 300
        }
        h.post { WvClean.kill(wv); wv = null }
        if (found > 0) return null
        return if (tried.isEmpty()) "tidak ada request media (setelah play & scroll otomatis)" else "${tried.size} request media, semua ditolak"
    }
    private fun hostOf(page: String): String = (try { android.net.Uri.parse(page).host ?: "" } catch (e: Throwable) { "" }).lowercase().removePrefix("www.")

    /** Host Pack: pembuka khusus host streaming (Streamtape, Doodstream, Mixdrop, Filemoon-packed, Rumble, OK.ru, VK, Bilibili, Instagram embed, Telegram). Deteksi lewat isi halaman, bukan hanya nama host. */
    fun hostPack(page: String): String? {
        val host = hostOf(page)
        val found = LinkedHashMap<String, String?>()
        var title = ""
        fun add(u: String?, r: String?) { if (u != null && u.startsWith("http") && !adRe.containsMatchIn(u)) found.putIfAbsent(u, r) }
        val rnd = java.util.Random()
        when {
            host.endsWith("rumble.com") -> {
                var id = Regex("rumble\\.com/embed/(v[a-z0-9]+)").find(page)?.groupValues?.get(1)
                if (id == null) { val h = get(page, UA_DESK) ?: return "Rumble tidak terbuka"; id = Regex("rumble\\.com/embed/(v[a-z0-9]+)").find(norm(h))?.groupValues?.get(1); title = titleOf(h) }
                if (id == null) return "ID Rumble tidak ditemukan"
                val j = get("https://rumble.com/embedJS/u3/?request=video&ver=2&v=$id", UA_DESK, "https://rumble.com/") ?: return "Rumble API tidak terbuka"
                for (m in urlRe.findAll(norm(j))) { val x = m.value.trimEnd('.', ',', ';', ')'); if (extRe.containsMatchIn(x)) add(x, "https://rumble.com/") }
            }
            host.endsWith("ok.ru") -> {
                val h = get(page, UA_DESK) ?: return "OK.ru tidak terbuka"
                title = titleOf(h)
                val o = Regex("data-options=\"([^\"]+)\"").find(h)?.groupValues?.get(1) ?: return "OK.ru: data video tidak ada"
                val t = norm(o.replace("&quot;", "\"").replace("&amp;", "&"))
                for (m in Regex("\"(?:url|hlsManifestUrl|ondemandHls|dashManifestUrl|hlsMasterPlaylistUrl)\"\\s*:\\s*\"(https?:[^\"]+)\"").findAll(t)) {
                    val x = m.groupValues[1]; if (extRe.containsMatchIn(x) || x.contains("type=") || x.contains("okcdn")) add(x, "https://ok.ru/")
                }
            }
            host.endsWith("vk.com") || host == "vkvideo.ru" -> {
                val h = get(page, UA_DESK, "https://vk.com/") ?: return "VK tidak terbuka"
                title = titleOf(h)
                for (m in Regex("\"(?:url\\d{3,4}|hls|hls_ondemand|dash_sep|dash_webm|mp4_\\d+)\"\\s*:\\s*\"(https?:[^\"]+)\"").findAll(norm(h))) add(m.groupValues[1], "https://vk.com/")
            }
            host.endsWith("bilibili.com") -> {
                val bv = Regex("(BV[0-9A-Za-z]{10})").find(page)?.groupValues?.get(1) ?: return "BV Bilibili tidak ditemukan"
                val v = JSONObject(get("https://api.bilibili.com/x/web-interface/view?bvid=$bv", UA_DESK, "https://www.bilibili.com/") ?: return "Bilibili tidak terbuka")
                val d = v.optJSONObject("data") ?: return "Bilibili: " + v.optString("message", "tanpa data").take(40)
                title = d.optString("title", "")
                val p = JSONObject(get("https://api.bilibili.com/x/player/playurl?bvid=$bv&cid=${d.optLong("cid")}&qn=80&fnval=0&platform=html5&high_quality=1", UA_DESK, "https://www.bilibili.com/") ?: return "Bilibili playurl gagal")
                val du = p.optJSONObject("data")?.optJSONArray("durl") ?: return "Bilibili: butuh login/tanpa durl"
                for (i in 0 until du.length()) add(du.optJSONObject(i)?.optString("url", ""), "https://www.bilibili.com/")
            }
            host.endsWith("instagram.com") -> {
                val code = Regex("instagram\\.com/(?:[^/]+/)?(?:p|reel|reels|tv)/([A-Za-z0-9_-]+)").find(page)?.groupValues?.get(1) ?: return "kode Instagram tidak ditemukan"
                val h = get("https://www.instagram.com/p/$code/embed/captioned/", UA_DESK) ?: return "Instagram embed tidak terbuka"
                title = titleOf(h)
                for (m in Regex("video_url\\\\?\"\\s*:\\s*\\\\?\"(https:[^\"\\\\]+)").findAll(norm(h))) add(m.groupValues[1], null)
                for (m in Regex("<video[^>]+src=\"([^\"]+)\"", ic).findAll(h)) add(norm(m.groupValues[1]), null)
            }
            host == "t.me" || host == "telegram.me" -> {
                val e = page.substringBefore('?') + "?embed=1&mode=tme"
                val h = get(e, UA_DESK) ?: return "Telegram tidak terbuka"
                for (x in harvest(e, h, false)) add(x, "https://t.me/")
            }
        }
        if (found.isEmpty()) {
            // deteksi lewat isi halaman (host streaming memakai banyak domain yang berganti-ganti)
            val pages = LinkedHashSet<String>(); pages.add(page)
            Regex("^(https?://[^/]+)/(?:d|v|f|file|embed-)/?([^/?#]+)").find(page)?.let { m -> pages.add(m.groupValues[1] + "/e/" + m.groupValues[2]); pages.add(m.groupValues[1] + "/embed/" + m.groupValues[2]) }
            var n = 0
            for (pg in pages) {
                if (n >= 3) break
                val h = get(pg, UA_DESK, if (pg == page) null else page) ?: continue
                n++
                if (title.isBlank()) title = titleOf(h)
                val t = norm(h)
                // Streamtape: robotlink + substring
                for (m in Regex("getElementById\\('(?:robotlink|ideoooolink|norobotlink|videolink)'\\)\\.innerHTML\\s*=\\s*['\"]([^'\"]+)['\"]\\s*\\+\\s*\\(?['\"]([^'\"]+)['\"]\\)?((?:\\.substring\\(\\d+\\))*)").findAll(t)) {
                    var tail = m.groupValues[2]
                    for (k in Regex("substring\\((\\d+)\\)").findAll(m.groupValues[3])) tail = tail.substring(Math.min(tail.length, k.groupValues[1].toInt()))
                    var u = m.groupValues[1] + tail
                    if (u.startsWith("//")) u = "https:$u"
                    add(if (u.contains("stream=")) u else "$u&stream=1", pg)
                }
                // Doodstream: pass_md5 + token
                val pm = Regex("(/pass_md5/[^'\"\\s]+)").find(t)?.groupValues?.get(1)
                if (pm != null) {
                    val tok = Regex("token=([a-z0-9]+)").find(t.substringAfter("pass_md5", ""))?.groupValues?.get(1) ?: pm.substringAfterLast('/')
                    val base = Regex("^(https?://[^/]+)").find(pg)?.groupValues?.get(1)
                    val b = if (base != null) get(base + pm, UA_DESK, pg, 6000)?.trim() else null
                    if (b != null && b.startsWith("http")) {
                        val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
                        val sb = StringBuilder(b); for (i in 0 until 10) sb.append(chars[rnd.nextInt(chars.length)])
                        add(sb.toString() + "?token=$tok&expiry=" + System.currentTimeMillis(), pg)
                    }
                }
                // Mixdrop & sejenis: JS dikemas (p,a,c,k,e,d) lalu wurl/file
                for (txt in SiteTool.unpack(h) + t) {
                    val x = norm(txt)
                    for (m in Regex("(?:wurl|vurl|surl)\\s*=\\s*[\"']([^\"']+)[\"']").findAll(x)) add(abs(pg, m.groupValues[1]), pg)
                    for (u in harvest(pg, x, false)) add(u, pg)
                }
            }
        }
        if (found.isEmpty()) return "tidak cocok dengan host/pola yang dikenal"
        var okN = 0
        for ((r, es) in found.entries.groupBy { it.value }) okN += emit("Host Pack", es.map { it.key }, r, title)
        return if (okN > 0) null else "${found.size} link ditolak"
    }
}


/** v1.189: Auto-detect media di Browser Alfy (terutama X/Twitter): <video> yang muncul di layar (IntersectionObserver) langsung memicu scan HLS Sniffer. */
object VideoWatch {
    private val h = Handler(Looper.getMainLooper())
    private val JS = """(function(){if(window.__alfyVW)return;window.__alfyVW=1;var seen=new WeakSet(),t=null;
function rep(v){var u='';try{u=v.currentSrc||v.src||'';}catch(e){}try{AlfyV.v(u&&u.indexOf('http')===0?u:'');}catch(e){}}
var io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting&&!en.target.__avr){en.target.__avr=1;rep(en.target);
 en.target.addEventListener('loadeddata',function(){en.target.__avr=0;},{once:true});}});},{threshold:0.5});
function add(v){if(seen.has(v))return;seen.add(v);io.observe(v);}
function all(){document.querySelectorAll('video').forEach(add);}
try{new MutationObserver(function(){if(t)return;t=setTimeout(function(){t=null;all();},120);}).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}
all();})();"""

    fun inject(w: WebView, url: String?) {
        if (url == null || !url.startsWith("http") || !Scan.enabled()) return
        try { w.evaluateJavascript(JS, null) } catch (e: Throwable) { }
    }

    class Bridge(private val t: BrowserTab) {
        @Volatile private var last = 0L
        @JavascriptInterface fun v(src: String?) {
            if (BrowserTabs.current() !== t) return
            val page = t.url ?: return
            if (!page.startsWith("http") || !SiteSettings.scan(page) || !Scan.enabled()) return
            val u = src ?: ""
            val now = android.os.SystemClock.elapsedRealtime()
            if (now - last < 2500) return
            last = now
            h.post {
                try { if (u.contains(".m3u8", true) && !WebTool.isAd(u, page)) Resolver.noteHls(u, page, t.wv.settings.userAgentString) } catch (e: Throwable) { }
                try { Chain.core(page, "Auto-detect media (video terlihat)") } catch (e: Throwable) { }
            }
        }
    }
}
