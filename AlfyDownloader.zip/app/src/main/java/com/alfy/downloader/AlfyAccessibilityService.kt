package com.alfy.downloader

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

class AlfyAccessibilityService : AccessibilityService() {
    private val skip = listOf("subscription", "live", "tren", "beranda", "notifikasi", "anda", "shorts", "disulih", "bagikan",
        "simpan", "remix", "suka", "komentar", "like", "share", "comment", "subscribe", "telusuri", "search", "lainnya",
        "kembali", "back", "more", "home", "library", "trending", "explore", "jelajahi", "buat", "create", "iklan", "sponsor")

    private val urlRe = Regex("https?://[^\\s\"'<>)]+")
    // alamat tanpa "https://" yang sering tampil di layar aplikasi lain (mis. "tiktok.com/@x/video/123")
    private val bareRe = Regex("(?<![\\w/.@-])(?:www\\.|m\\.|vm\\.|vt\\.)?(?:youtube\\.com|youtu\\.be|tiktok\\.com|instagram\\.com|facebook\\.com|fb\\.watch|x\\.com|twitter\\.com|vimeo\\.com|dailymotion\\.com|reddit\\.com|twitch\\.tv|soundcloud\\.com|bilibili\\.com|threads\\.net)/[^\\s\\\"'<>)]+", RegexOption.IGNORE_CASE)
    private val durRe = Regex("\\d+\\s*(menit|detik|jam|minute|second|hour|min|sec)", RegexOption.IGNORE_CASE)
    /** v1.190: set FIFO berbatas (hemat RAM) untuk deduplikasi thumbnail; nilai = berlaku sampai (uptime ms). */
    private class Fifo(private val cap: Int) {
        private val m = LinkedHashMap<String, Long>()
        @Synchronized fun fresh(k: String, now: Long): Boolean { val v = m[k]; return v != null && v > now }
        @Synchronized fun put(k: String, until: Long) {
            m.remove(k); m[k] = until
            while (m.size > cap) { val it = m.entries.iterator(); it.next(); it.remove() }
        }
    }
    private val thumbDone = Fifo(250)
    private val thumbNeg = Fifo(200)
    private var thumbAt = 0L
    private val hostRe = Regex("^[\\w.-]+\\.[a-zA-Z]{2,}(/\\S*)?$")
    private val barIds = listOf(
        "url_bar", "url_field", "location_bar_edit_text", "mozac_browser_toolbar_url_view",
        "url_bar_title", "omnibarTextInput", "toolbar_url", "search_box_text", "url_edit_text"
    )

    private val ht = android.os.HandlerThread("alfy-scan").also { it.start() }
    private val bg = android.os.Handler(ht.looper)
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    @Volatile private var busy = false
    private var last = 0L
    private var lastFull = 0L
    private var candQ = ""
    private var doneQ = ""
    private var lastPkg = ""
    @Volatile private var titleClickAt = 0L

    companion object {
        @Volatile var inst: AlfyAccessibilityService? = null
        /** v1.12: aplikasi yang sedang di depan (dipakai kunci mode YouTube: hanya deteksi layar). */
        @Volatile var fgPkg: String = ""
    }

    // v1.12: nama channel dari keterangan thumbnail / baris channel ("Buka saluran X", "X • 1,2 jt subscriber")
    private val chanRe = Regex("(?i)^(?:buka|kunjungi|lihat|go to|open|view)\\s+(?:saluran|channel)\\s+(.+)$")
    private val subRe = Regex("(?i)^(.{2,60}?)\\s*[•·,]\\s*[\\d.,]+\\s*(?:[km]|rb|jt|ribu|juta)?\\s*(?:subscribers?|pelanggan)")
    private val statRe = Regex("(?i)\\d.*(ditonton|views?|subscribers?|pelanggan|x tayang)")
    private fun channelFrom(t: String): String? {
        for (p in t.split(" - ", " – ", " • ", "\n")) {
            chanRe.find(p.trim())?.let { m -> val c = m.groupValues[1].trim().trimEnd('.', ',').take(60); if (c.length >= 2) return c }
        }
        subRe.find(t.trim())?.let { m -> val c = m.groupValues[1].trim(); if (c.length >= 2) return c }
        return null
    }
    private class YQ(val first: String, val second: Boolean, val chan: String)
    private fun vis(n: AccessibilityNodeInfo): Boolean = try { n.isVisibleToUser } catch (e: Exception) { true }

    private val cmgr by lazy { getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager }
    private var lastClipTxt = ""
    private var evMask = 0
    private var clipOn = false
    /** Scan/tool OFF => sistem berhenti mengirim event, listener clipboard dilepas, handler dibersihkan. */
    fun applyState() {
        val s = Scan.enabled()
        val full = s && Tool.on("Aksesibilitas")
        val fgOnly = s && !full && Tool.on("Logcat root")   // hanya untuk fgPkg (kunci mode YouTube)
        val mask = if (full) evMask else if (fgOnly) AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED else 0
        try { val i = serviceInfo; if (i != null && i.eventTypes != mask) { i.eventTypes = mask; serviceInfo = i } } catch (e: Exception) { }
        if (full && !clipOn) { clipOn = true; try { cmgr.addPrimaryClipChangedListener(clipL) } catch (e: Exception) { } }
        if (!full) {
            if (clipOn) { clipOn = false; try { cmgr.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { } }
            bg.removeCallbacksAndMessages(null); main.removeCallbacksAndMessages(null); busy = false
        }
        // Fase 6: tool Aksesibilitas (dan kunci YouTube) OFF -> layanan dilepas total, bukan sekadar diam
        if (mask == 0 && android.os.Build.VERSION.SDK_INT >= 24) { try { disableSelf() } catch (e: Exception) { } }
    }
    private val clipL = android.content.ClipboardManager.OnPrimaryClipChangedListener {
        // layanan aksesibilitas boleh membaca clipboard di latar belakang -> otomatis, tanpa paste
        if (Scan.enabled()) main.post { try { if (!readClipDirect()) FloatingService.inst?.pullClip() ?: NetSniffer.readClipRootOnce() } catch (e: Throwable) { } }
    }

    /** Baca clipboard langsung dari layanan aksesibilitas. true bila ada tautan yang ditemukan. */
    fun readClipDirect(): Boolean {
        return try {
            val t = cmgr.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: return false
            if (t.isBlank()) return false
            val urls = urlRe.findAll(t).map { it.value.trimEnd('.', ',', ';', ')') }.toList()
            if (urls.isEmpty()) return t.isNotBlank()
            urls.forEach { Resolver.rescan(it, null, "Clipboard (aksesibilitas)") }
            lastClipTxt = t
            Resolver.diag = "Clipboard: memindai ${urls.size} tautan…"
            true
        } catch (e: Exception) { false }
    }

    override fun onServiceConnected() {
        super.onServiceConnected(); inst = this
        goForeground()
        try {
            val i = serviceInfo
            if (i != null) {
                i.eventTypes = i.eventTypes or AccessibilityEvent.TYPE_VIEW_CLICKED or AccessibilityEvent.TYPE_VIEW_LONG_CLICKED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_SCROLLED
                i.notificationTimeout = 50
                evMask = i.eventTypes
                serviceInfo = i
            }
        } catch (e: Exception) { }
        try { applyState() } catch (e: Throwable) { }
    }

    /** Jalankan sebagai Foreground Service (notifikasi persisten) agar tidak dimatikan sistem (mis. MIUI/Xiaomi). */
    private fun goForeground() {
        try {
            startForeground(3, makeNotif(this, "Layanan aksesibilitas aktif", icon = android.R.drawable.stat_sys_download_done, channel = "alfy_access"))
        } catch (e: Exception) { }
    }

    fun keyboardShown(): Boolean = try { windows.any { it.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD } } catch (e: Exception) { false }

    /** Ambil jendela aplikasi yang sedang dibuka (bukan jendela AlfyDownloader sendiri). */
    private fun appRoot(): AccessibilityNodeInfo? {
        try {
            val r = rootInActiveWindow
            if (r != null && r.packageName?.toString() != packageName) return r
        } catch (e: Exception) { }
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) return x
            }
        } catch (e: Exception) { }
        return null
    }

    /** Pindai layar yang sedang terbuka (tombol 🔍): langsung, tanpa menunggu. */
    fun scanNow(fresh: Boolean = false) {
        // v1.61: scan baru = ambil aplikasi yang sedang di depan, buang cache lama, hanya layar aplikasi itu yang dibaca
        val fg = (try { appRoot()?.packageName?.toString() } catch (e: Exception) { null }) ?: fgPkg
        if (fg.isNotEmpty() && fg != packageName && (fresh || fg != Resolver.activePkg)) Resolver.beginScope(fg)
        // v77: tombol 🔍 = Force Re-scan: buang cache 'sudah discan' & jeda gagal agar link yang baru dihapus dari daftar masuk lagi
        if (fresh) Resolver.forgetForManual()
        bg.post { try {
            var roots = scopedRoots()
            for (i in 0 until 4) {
                if (roots.isNotEmpty()) break
                try { Thread.sleep(200) } catch (e: Exception) { }
                roots = scopedRoots()
            }
            if (roots.isEmpty()) { Resolver.diag = "Layar belum terbaca, coba lagi"; return@post }
            Resolver.diag = "Memindai layar…"
            var found = 0
            for (root in roots) try { found += process(root, root.packageName?.toString() ?: "", true, false) } catch (e: Exception) { }
            // Visual Scan universal: tidak ada URL -> teks paling menonjol jadi kata kunci ytsearch5 (yt-dlp)
            val fgp = roots.firstOrNull()?.packageName?.toString() ?: ""
            val ytApp = fgp.contains("youtube", true) && !Block.youtube()
            if (found == 0 && !ytApp) {
                if (fgp.startsWith("com.facebook", true)) {
                    Resolver.diag = "FB/FB Lite: tidak ada URL di layar — gunakan Bagikan → Salin tautan / Share ke Alfy"
                } else {
                    val q = try { prominentText(roots) } catch (e: Exception) { null }
                    if (q != null) { found = 1; Resolver.searchYoutube(q, false, true, "") }
                }
            }
            if (found == 0 && Resolver.diag == "Memindai layar…") Resolver.diag = "Layar dipindai: tidak ada tautan/teks judul terbaca"
            // hemat RAM: hentikan pemindaian lanjutan setelah hasil dikirim
            if (found > 0) bg.removeCallbacksAndMessages(null)
        } catch (e: Throwable) { } }
    }

    private val junkRe = Regex("(?i)^(follow|following|followed|ikuti|mengikuti|like|liked|likes|comment|comments|komentar|play|pause|putar|jeda|shuffle|acak|repeat|ulangi|next|previous|selanjutnya|sebelumnya|skip|lewati|ad|ads|iklan|advertisement|premium|upgrade|download|unduh|share|bagikan|save|simpan|add|tambah|close|tutup|menu|search|cari|home|beranda|your library|library|koleksi|now playing|sedang diputar|lyrics|lirik|queue|antrean|cast|more|lainnya|back|kembali|settings|pengaturan|reply|balas|send|kirim|new|baru|live|story|stories|reels|explore|jelajahi|profile|profil)$")
    private val timeRe = Regex("^[-+]?\\d{1,2}(:\\d{2}){1,2}$|^\\d+\\s*[kKmMbB]?$|^[\\d.,]+\\s*(rb|jt|k|m|ribu|juta)?\\s*(likes?|suka|views?|komentar|comments?|followers?|pengikut)?$")

    /** Teks judul paling menonjol di layar (node terlihat, tinggi/atas terbesar), setelah membuang teks sampah. */
    private fun prominentText(roots: List<AccessibilityNodeInfo>): String? {
        class C(val t: String, val top: Int, val h: Int, val left: Int)
        val list = ArrayList<C>()
        val seen = HashSet<String>()
        val cnt = IntArray(1)
        val screenH = resources.displayMetrics.heightPixels
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 30 || cnt[0]++ > 1500) return
            if (!vis(n)) return
            for (s0 in listOf(n.text?.toString(), n.contentDescription?.toString())) {
                val t = s0?.trim()?.replace(Regex("\\s+"), " ") ?: continue
                if (t.length !in 3..120 || !seen.add(t.lowercase())) continue
                if (junkRe.matches(t) || timeRe.matches(t) || durRe.matches(t) || isNavText(t) || statRe.containsMatchIn(t)) continue
                if (t.startsWith("http") || t.all { !it.isLetter() }) continue
                val r = android.graphics.Rect(); try { n.getBoundsInScreen(r) } catch (e: Exception) { continue }
                if (r.top < screenH * 0.06 || r.top > screenH * 0.85) continue   // abaikan status/toolbar atas & bar bawah
                list.add(C(t, r.top, r.height(), r.left))
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        for (r in roots) walk(r, 0)
        if (list.isEmpty()) return null
        val best = list.maxByOrNull { it.h * 2 + minOf(it.t.length, 60) } ?: return null
        // judul pendek (mis. Spotify: lagu + artis berdekatan) -> gabungkan teks terdekat di bawahnya
        // v1.190: judul utama + sub-teks (artis/channel) tepat di bawahnya & sejajar kiri -> kata kunci lebih akurat
        if (best.t.length < 60) {
            val sw = resources.displayMetrics.widthPixels
            val sub = list.filter {
                it !== best && it.top >= best.top && it.top - best.top < 260 && it.t.length in 2..50 &&
                    kotlin.math.abs(it.left - best.left) < sw * 0.25 && !best.t.contains(it.t, true) && !it.t.contains(best.t, true)
            }.minByOrNull { it.top - best.top }
            if (sub != null) return (best.t + " " + sub.t).take(120)
        }
        return best.t
    }

    private fun clipSoon() {
        for (d in longArrayOf(300, 1200)) main.postDelayed({
            try {
                if (readClipDirect()) return@postDelayed
                val f = FloatingService.inst
                if (f != null) f.pullClip() else NetSniffer.readClipRootOnce()
            } catch (e: Throwable) { }
        }, d)
    }

    /** Semua jendela aplikasi (bukan AlfyDownloader) — termasuk popup/bottom sheet. */
    private fun scopedRoots(): List<AccessibilityNodeInfo> {
        val a = Resolver.activePkg
        val l = allRoots()
        return if (a.isEmpty()) l else l.filter { it.packageName?.toString() == a }
    }

    private fun allRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION && w.type != AccessibilityWindowInfo.TYPE_SYSTEM) continue
                val x = w.root ?: continue
                if (x.packageName?.toString() != packageName) out.add(x)
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) appRoot()?.let { out.add(it) }
        return out
    }

    private fun isNavText(t: String): Boolean { val l = t.lowercase().trim(); return skip.any { l == it || l.startsWith("$it ") } }

    /** Teks keterangan thumbnail YouTube: "Judul - 5 menit - Buka saluran X - 1 jt x ditonton ..." -> ambil judul. */
    private fun titleFromDesc(d: String): String? {
        val parts = d.split(" - ", " – ", " • ").map { it.trim() }.filter { it.isNotEmpty() }
        val t = parts.firstOrNull() ?: return null
        if (t.length < 4 || isNavText(t)) return null
        return t.take(120)
    }

    /** Setelah klik video/tautan: pindai layar di latar belakang (tunggu layar baru muncul). */
    private fun burst(pkg: String) {
        for (d in longArrayOf(1500, 3500)) bg.postDelayed({
            try {
                val r = appRoot() ?: return@postDelayed
                process(r, r.packageName?.toString() ?: pkg, false, true)
            } catch (ex: Exception) { }
        }, d)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        handleEvent(e)
    }

    private fun handleEvent(e: AccessibilityEvent) {
        if (!Scan.enabled()) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) {
            // v1.61: browser Alfy di depan = scope aplikasi sendiri
            if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.className?.toString()?.endsWith("BrowserActivity") == true && Resolver.activePkg != packageName) Resolver.beginScope(packageName)
            return
        }
        if (!Scan.enabled()) return   // v1.11: scan otomatis dimatikan lewat ⚙ di panel
        val type = e.eventType
        if (type != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED && !pkg.contains("systemui") && !pkg.contains("inputmethod") && !pkg.contains("keyboard")) fgPkg = pkg
        // v1.61: pindah aplikasi di depan -> buang semua link/cache aplikasi sebelumnya
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg == fgPkg && pkg != Resolver.activePkg) Resolver.beginScope(pkg)
        if (!Tool.on("Aksesibilitas")) return   // v1.12: tool dimatikan lewat ⚙ (tombol 🔍 manual tetap jalan)
        val txt = (e.text?.joinToString(" ") ?: "") + " " + (e.contentDescription ?: "")
        val low = txt.lowercase()

        // Klik / tahan video atau tautan -> langsung pindai di latar belakang
        if (type == AccessibilityEvent.TYPE_VIEW_CLICKED || type == AccessibilityEvent.TYPE_VIEW_LONG_CLICKED) {
            val sb = StringBuilder(txt)
            try {
                var n: AccessibilityNodeInfo? = e.source
                var d = 0
                while (n != null && d < 4) {
                    sb.append(' ').append(n.text ?: "").append(' ').append(n.contentDescription ?: "")
                    n = n.parent; d++
                }
            } catch (ex: Exception) { }
            val all = sb.toString()
            urlRe.findAll(all).forEach { Resolver.submit(it.value.trimEnd('.', ',', ';', ')'), null, true, "Aksesibilitas (klik)") }
            if (pkg.contains("youtube", true)) {
                // thumbnail yang diklik: judulnya ada di deskripsi -> langsung cari video itu
                val cds = ArrayList<String>()
                try {
                    var n: AccessibilityNodeInfo? = e.source; var d = 0
                    while (n != null && d < 5) { n.contentDescription?.toString()?.let { cds.add(it) }; n.text?.toString()?.let { cds.add(it) }; n = n.parent; d++ }
                } catch (ex: Exception) { }
                cds.add(txt)
                val best = cds.filter { it.length > 12 && !isNavText(it) }.maxByOrNull { it.length }
                val t = best?.let { titleFromDesc(it) }
                val chC = cds.firstNotNullOfOrNull { channelFrom(it) } ?: ""
                if (t != null) { titleClickAt = SystemClock.uptimeMillis(); candQ = t; doneQ = t; Resolver.latestYt = t; Resolver.searchYoutube(t, false, true, chC) }
            }
            val l = all.lowercase()
            if (l.contains("salin") || l.contains("copy") || l.contains("copied")) clipSoon()
            burst(pkg)
            return
        }

        // Toast "tautan disalin" / pratinjau clipboard sistem -> baca clipboard terbaru
        if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED || pkg.contains("systemui")) {
            if (low.contains("disalin") || low.contains("copied") || low.contains("salin") || low.contains("clipboard") ||
                low.contains("papan klip") || low.contains("tautan") || low.contains("link")) clipSoon()
            if (pkg == Resolver.activePkg) urlRe.findAll(txt).forEach { Resolver.submit(it.value, null, false, "Aksesibilitas (notifikasi)") }   // v1.61: notifikasi aplikasi latar diabaikan
            if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) return
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != lastPkg) { lastPkg = pkg; burst(pkg) }
        if (type == AccessibilityEvent.TYPE_VIEW_SCROLLED || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) xTick()
        // v1.190: selesai geser/berubah isi di YouTube atau browser -> pindai ulang layar (debounce ~350 ms), tanpa menunggu 3 dtk
        if ((type == AccessibilityEvent.TYPE_VIEW_SCROLLED || type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) && (pkg.contains("youtube", true) || isBrowserPkg(pkg))) scheduleScrollScan()
        if (busy) return
        val now = SystemClock.uptimeMillis()
        if (now - last < 200) return
        last = now
        busy = true
        bg.post {
            try {
                val root = rootInActiveWindow ?: return@post
                process(root, pkg, false, false)
            } catch (ex: Exception) { } finally { busy = false }
        }
    }

    override fun onDestroy() { inst = null; try { stopForeground(true) } catch (e: Exception) { }; bg.removeCallbacksAndMessages(null); main.removeCallbacksAndMessages(null); try { cmgr.removePrimaryClipChangedListener(clipL) } catch (e: Exception) { }; try { ht.quitSafely() } catch (e: Exception) { }; super.onDestroy() }

    @Volatile private var curPkg = ""

    // ---------- v1.190: scan layar ber-debounce saat scroll ----------
    @Volatile private var scrollPending = false
    private var scrollSince = 0L
    private val scrollScanRun = Runnable {
        scrollPending = false
        try {
            if (!Scan.enabled() || !Tool.on("Aksesibilitas")) return@Runnable
            val r = rootInActiveWindow ?: return@Runnable
            val p = r.packageName?.toString() ?: fgPkg
            if (p.isEmpty() || p == packageName) return@Runnable
            process(r, p, false, false)
        } catch (e: Exception) { }
    }
    /** Debounce 350 ms; bila event terus datang, tunggu maksimal ~1,2 dtk supaya tetap berjalan. */
    private fun scheduleScrollScan() {
        val now = SystemClock.uptimeMillis()
        if (!scrollPending) { scrollPending = true; scrollSince = now }
        else if (now - scrollSince > 1200L) return
        bg.removeCallbacks(scrollScanRun); bg.postDelayed(scrollScanRun, 350L)
    }

    private val browserHints = listOf("chrome", "firefox", "fenix", "brave", "opera", "emmx", "sbrowser", "browser", "duckduckgo", "vivaldi", "kiwi",
        "mozilla", "ucmobile", "mark.via", "bromite", "ecosia", "puffin", "cromite", "whale", "torproject")
    private fun isBrowserPkg(pkg: String): Boolean = browserHints.any { pkg.contains(it, true) }

    private fun process(root: AccessibilityNodeInfo?, pkg: String, manual: Boolean, click: Boolean): Int {
        if (root == null) return 0
        return processImpl(root, pkg, manual, click)
    }

    private fun processImpl(root: AccessibilityNodeInfo, pkg: String, manual: Boolean, click: Boolean): Int {
        if (Resolver.activePkg.isNotEmpty() && pkg != Resolver.activePkg) return 0   // v1.61: hanya aplikasi aktif
        var found = 0
        curPkg = pkg
        for (n in barIds) {
            try {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/$n")?.forEach { v ->
                    v?.text?.toString()?.let { handleBar(it) }
                }
            } catch (t: Throwable) { }
        }
        val yt = pkg.contains("youtube", true) && !Block.youtube()
        if (yt) {
            if (manual) {
                val q = ytQuery(root)   // v1.12: judul + handle + NAMA CHANNEL dibaca dari layar
                if (q == null) Resolver.diag = "YouTube: teks video di layar tidak terbaca"
                else { candQ = q.first; doneQ = q.first; Resolver.searchYoutube(q.first, q.second, true, q.chan) }
            } else if (click) {
                if (SystemClock.uptimeMillis() - titleClickAt > 6000 && onPlayer(root)) {
                    val q = ytQuery(root, true)
                    if (q != null && q.first != doneQ) { candQ = q.first; doneQ = q.first; Resolver.latestYt = q.first; Resolver.searchYoutube(q.first, q.second, true, q.chan) }
                }
            } else {
                if (onPlayer(root)) ytAuto(root)
                // v1.190: baca SEMUA thumbnail yang terlihat (beranda/search/channel/subscriptions/Shorts/miniplayer + daftar di bawah pemutar);
                // setelah mengetuk video cukup 2 dtk (dulu 15 dtk) supaya scroll berikutnya langsung dipindai lagi
                if (Scan.enabled() && Repo.prefs().getBoolean("autoThumb", true) && SystemClock.uptimeMillis() - titleClickAt > 2_000) thumbScan(root)
            }
        }
        if (!yt && !manual) autoPlay(root, pkg)
        // Pindai semua teks layar untuk alamat http(s) (otomatis, dibatasi agar ringan)
        val now = SystemClock.uptimeMillis()
        if (manual || click || now - lastFull > 800) {
            lastFull = now
            found += scan(root, 0, IntArray(1), manual || click, if (manual) "Aksesibilitas (🔍 manual)" else if (click) "Aksesibilitas (klik)" else "Aksesibilitas (layar)")
        }
        return found
    }

    // ---------- v1.190: thumbnail pasif — baca SEMUA thumbnail yang terlihat di layar ----------
    private class Th(val t: String, val ch: String, val shorts: Boolean)
    /** st: 0 = belum ada penanda video, 1 = kartu valid, 2 = terlalu besar / gabungan beberapa kartu (berhenti naik). */
    private class Card(val th: Th?, val st: Int)

    private val clockRe = Regex("\\b\\d{1,2}:\\d{2}\\b")
    private val viewRe = Regex("(?i)ditonton|\\bviews?\\b|tayang")
    private val shortsRe = Regex("(?i)\\bshorts?\\b")
    private val thumbSepRe = Regex("\\s[-–•]\\s|\\n|,\\s")
    private val thumbIndRe = Regex("(?i)\\b\\d{1,2}:\\d{2}\\b|\\d+\\s*(?:menit|detik|jam|minute|second|hour|min|sec)|ditonton|\\bviews?\\b|tayang|\\bshorts?\\b|putar video|play video|(?:buka|kunjungi|lihat|go to|open|view)\\s+(?:saluran|channel)")

    /** Teks calon JUDUL video (10..120 huruf, bukan navigasi/statistik/angka/jam/baris meta channel). */
    private fun titleLike(t: String): Boolean {
        if (t.length !in 10..120) return false
        if (isNavText(t) || statRe.containsMatchIn(t) || junkRe.matches(t) || timeRe.matches(t) || durRe.matches(t)) return false
        if (t.startsWith("http") || t.startsWith("@") || t.none { it.isLetter() }) return false
        if (t.contains(" • ")) return false
        return true
    }

    /** Pola 1: contentDescription kartu ("Judul - 5 menit - Buka saluran X - 1 jt ditonton - putar video") dengan pemisah " - ", " • ", "\n", ", ". */
    private fun parseThumbDesc(cd: String): Th? {
        if (cd.length < 12 || cd.length > 600) return null
        val seps = thumbSepRe.findAll(cd).toList()
        if (seps.isEmpty()) return null
        var segStart = 0
        var prevEnd = -1
        var cut = -1
        for (i in 0..seps.size) {
            val segEnd = if (i < seps.size) seps[i].range.first else cd.length
            val seg = cd.substring(segStart, segEnd)
            if (i > 0 && thumbIndRe.containsMatchIn(seg)) { cut = prevEnd; break }
            prevEnd = segEnd
            if (i < seps.size) segStart = seps[i].range.last + 1
        }
        if (cut < 4) return null
        val title = cd.substring(0, cut).trim().trimEnd(',', '-', '–', '•', ' ')
        if (title.length !in 4..120 || isNavText(title) || junkRe.matches(title) || timeRe.matches(title) || statRe.containsMatchIn(title) ||
            title.startsWith("http") || title.none { it.isLetter() }) return null
        var ch = ""
        for (seg in thumbSepRe.split(cd.substring(cut))) {
            val m = chanRe.find(seg.trim()) ?: continue
            val c = m.groupValues[1].trim().trimEnd('.', ',').take(60)
            if (c.length >= 2) { ch = c; break }
        }
        if (ch.isEmpty()) ch = channelFrom(cd) ?: ""
        return Th(title, ch, shortsRe.containsMatchIn(cd) && !clockRe.containsMatchIn(cd))
    }

    /** Pola 2: kartu tanpa judul lengkap di contentDescription — analisis teks anak di dalam kontainer [c] (maks 60 node). */
    private fun cardOf(c: AccessibilityNodeInfo): Card {
        class T(val s: String, val top: Int)
        val cands = ArrayList<T>()
        val others = ArrayList<T>()
        val clocks = HashSet<String>()
        val views = HashSet<String>()
        var shortsMark = false
        var meta = ""
        var big = false
        val cnt = IntArray(1)
        val r = android.graphics.Rect()
        fun w(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || big) return
            if (d > 7 || cnt[0]++ > 60) { big = true; return }
            for (s0 in arrayOf(n.text?.toString(), n.contentDescription?.toString())) {
                val s = s0?.trim() ?: continue
                if (s.isEmpty()) continue
                if ((clockRe.containsMatchIn(s) || durRe.containsMatchIn(s)) && s.length <= 30 && !s.contains(" - ")) clocks.add(s)
                else if (viewRe.containsMatchIn(s) && s.length < 120) { views.add(s.lowercase()); if (s.contains(" • ") && meta.isEmpty()) meta = s }
                else if (shortsRe.containsMatchIn(s) && s.length <= 24) shortsMark = true
            }
            val tx = n.text?.toString()?.trim()
            if (tx != null) {
                r.setEmpty(); try { n.getBoundsInScreen(r) } catch (e: Exception) { }
                if (titleLike(tx)) cands.add(T(tx, r.top))
                else if (tx.length in 2..60 && !isNavText(tx) && !statRe.containsMatchIn(tx) && !viewRe.containsMatchIn(tx) && !timeRe.matches(tx) &&
                    !junkRe.matches(tx) && !clockRe.containsMatchIn(tx) && (tx.startsWith("@") || tx.any { it.isLetter() })) others.add(T(tx, r.top))
            }
            for (i in 0 until n.childCount) { if (big) return; w(n.getChild(i), d + 1) }
        }
        w(c, 0)
        if (big) return Card(null, 2)
        if (clocks.size > 1 || views.size > (if (clocks.isNotEmpty()) 2 else 1)) return Card(null, 2)
        if ((clocks.isEmpty() && views.isEmpty() && !shortsMark) || cands.isEmpty()) return Card(null, 0)
        val sorted = cands.sortedWith(compareBy<T>({ it.top }, { -it.s.length }))
        val title = sorted.first()
        // channel: baris meta "Channel • 1 jt x ditonton" -> bagian pertama; lain-lain: handle @x, atau teks pendek di bawah judul
        var ch = ""
        if (meta.isNotEmpty()) {
            val p = meta.split(" • ")[0].trim()
            if (p.length in 2..60 && !statRe.containsMatchIn(p) && !viewRe.containsMatchIn(p) && !durRe.containsMatchIn(p)) ch = p
        }
        if (ch.isEmpty()) ch = others.firstOrNull { it.s.startsWith("@") }?.s ?: ""
        if (ch.isEmpty()) ch = others.filter { it.top >= title.top }.minByOrNull { it.top }?.s
            ?: sorted.drop(1).firstOrNull { it.s.length <= 60 }?.s ?: ""
        return Card(Th(title.s, ch, shortsMark && clocks.isEmpty()), 1)
    }

    /**
     * Otomatis saat daftar/hasil pencarian YouTube hanya DILIHAT (beranda/search/channel/subscriptions/Shorts, termasuk saat scroll):
     * kumpulkan SEMUA thumbnail baru yang terlihat (maks 8 per putaran; sisanya menyusul otomatis) -> antrean ringan Resolver.queueVisibleThumb.
     */
    private fun thumbScan(root: AccessibilityNodeInfo) {
        if (!Repo.prefs().getBoolean("autoThumb", true)) return
        val now = SystemClock.uptimeMillis()
        if (now - thumbAt < 400) return   // jeda ringan antar pindai
        thumbAt = now
        val screenH = resources.displayMetrics.heightPixels
        val cnt = IntArray(1)
        val checks = IntArray(1)
        val hits = ArrayList<Th>()
        val stack = ArrayList<AccessibilityNodeInfo>()
        val cache = java.util.IdentityHashMap<AccessibilityNodeInfo, Card>()
        val rect = android.graphics.Rect()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || hits.size >= 8 || d > 30 || cnt[0]++ > 3500) return
            if (!vis(n)) return   // hanya node yang benar-benar terlihat
            rect.setEmpty()
            try { n.getBoundsInScreen(rect) } catch (e: Exception) { return }
            if (!(rect.bottom > 0 && rect.top < screenH && rect.height() > 0)) return   // di luar layar (cache RecyclerView)
            val cd = n.contentDescription?.toString()
            val tx = n.text?.toString()
            // 0) ID video 11 karakter langsung (href/teks/deskripsi berisi watch?v= atau /shorts/)
            for (src in arrayOf(cd, tx)) {
                val id = src?.let { Resolver.ytRe.find(it)?.groupValues?.get(1) } ?: continue
                if (thumbDone.fresh("id:$id", now)) continue
                thumbDone.put("id:$id", Long.MAX_VALUE)
                hits.add(Th("https://www.youtube.com/watch?v=$id", "", false))
            }
            // 1) contentDescription kartu thumbnail (video + Shorts)
            if (cd != null) {
                val th = parseThumbDesc(cd)
                if (th != null) {
                    val k = th.t.lowercase()
                    if (!thumbDone.fresh(k, now)) { thumbDone.put(k, Long.MAX_VALUE); hits.add(th) }
                    return   // kartu sudah terbaca: tidak perlu turun ke anak-anaknya
                }
            }
            // 2) teks anak kartu (judul + channel terdekat dalam kontainer kartu yang sama)
            if (tx != null && checks[0] < 14) {
                val t = tx.trim()
                if (titleLike(t)) {
                    val k = t.lowercase()
                    if (!thumbDone.fresh(k, now) && !thumbNeg.fresh(k, now)) {
                        checks[0]++
                        var best: Th? = null
                        var lv = 1
                        while (lv <= 3 && stack.size - lv >= 0) {   // naik 1..3 level: ambil kontainer TERBESAR yang masih satu kartu
                            val c = stack[stack.size - lv]
                            val card = cache.getOrPut(c) { cardOf(c) }
                            if (card.st == 2) break
                            if (card.st == 1) best = card.th
                            lv++
                        }
                        if (best != null) {
                            val bk = best.t.lowercase()
                            if (!thumbDone.fresh(bk, now)) { thumbDone.put(bk, Long.MAX_VALUE); hits.add(best) }
                            if (bk != k) thumbNeg.put(k, now + 8000L)   // teks ini bukan judulnya (mis. nama channel)
                        } else thumbNeg.put(k, now + 8000L)
                    }
                }
            }
            stack.add(n)
            for (i in 0 until n.childCount) { if (hits.size >= 8) break; walk(n.getChild(i), d + 1) }
            stack.removeAt(stack.size - 1)
        }
        walk(root, 0)
        if (hits.isEmpty()) return
        for (h in hits) Resolver.queueVisibleThumb(h.t, h.shorts, h.ch)
        // masih ada yang belum terbaca (batas 8 per putaran) -> putaran berikutnya segera, tanpa menunggu event baru
        if (hits.size >= 8) { bg.removeCallbacks(scrollScanRun); bg.postDelayed(scrollScanRun, 500L) }
    }

    /** Teks YouTube di layar: handle channel + keterangan video. Mengembalikan (query, apakah Shorts). */
    private fun ytQuery(root: AccessibilityNodeInfo, visOnly: Boolean = false): YQ? {
        val texts = LinkedHashSet<String>()
        val tops = HashMap<String, Int>()
        val screenH = resources.displayMetrics.heightPixels
        fun add(s: String?, n: AccessibilityNodeInfo) {
            val t = s?.trim() ?: return
            if (t.isEmpty()) return
            if (texts.add(t) && visOnly) { val r = android.graphics.Rect(); try { n.getBoundsInScreen(r) } catch (e: Exception) { }; tops[t] = r.top }
        }
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || d > 25 || texts.size > 150) return
            if (visOnly && !vis(n)) return   // v1.12 mode otomatis: node yang tidak terlihat di layar diabaikan
            add(n.text?.toString(), n); add(n.contentDescription?.toString(), n)
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val handleRe = Regex("@[A-Za-z0-9._-]{3,}")
        val handle = texts.firstNotNullOfOrNull { handleRe.find(it)?.value }
        val chan = texts.firstNotNullOfOrNull { channelFrom(it) } ?: ""
        val shorts = texts.any { it.equals("shorts", true) }
        val cap = texts.filter { t ->
            t.length in 6..140 && !t.matches(Regex("[\\d.,: KkMmRrbBtT]+")) && t != handle &&
                (handle == null || !t.contains(handle)) && skip.none { t.lowercase().startsWith(it) } &&
                !statRe.containsMatchIn(t) && !chanRe.containsMatchIn(t) && !t.equals(chan, true) &&
                // otomatis: abaikan keterangan thumbnail rekomendasi & teks di bagian bawah layar (bukan judul video yang diputar)
                (!visOnly || shorts || ((tops[t] ?: 0) < screenH * 0.65 && !(durRe.containsMatchIn(t) && t.contains(" - "))))
        }.maxByOrNull { it.length }
        if (handle == null && cap == null) return null
        return YQ(((handle ?: "") + " " + (cap ?: "")).trim(), shorts, chan)
    }

    /** Otomatis: tunggu layar stabil sebentar (geser Shorts), baru cari video yang sedang tampil. */
    private fun ytAuto(root: AccessibilityNodeInfo) {
        val r = ytQuery(root, true) ?: return
        val q = r.first
        if (q == candQ) return
        candQ = q
        if (q == doneQ) return
        bg.postDelayed({
            if (candQ == q && doneQ != q) { doneQ = q; Resolver.latestYt = q; Resolver.searchYoutube(q, r.second, false, r.chan) }
        }, 800)
    }

    /** Layar pemutar YouTube (Shorts / halaman tonton) = ada tombol bagikan + aksi suka/simpan/remix. */
    private fun onPlayer(root: AccessibilityNodeInfo): Boolean {
        // v1.12: hanya tombol aksi yang TERLIHAT (diawali kata tombolnya) dan keduanya harus ada; judul video di feed yang
        // kebetulan memuat kata "like/save/suka" tidak lagi dianggap layar pemutar (penyebab video acak)
        var share = false; var act = false; var n = 0
        fun walk(x: AccessibilityNodeInfo?, d: Int) {
            if (x == null || d > 25 || n++ > 400 || (share && act)) return
            if (!vis(x)) return
            for (s in listOf(x.text?.toString(), x.contentDescription?.toString())) {
                val t = s?.trim()?.lowercase() ?: continue
                if (t.isEmpty() || (t.contains(" - ") && durRe.containsMatchIn(t))) continue
                if (t.startsWith("bagikan") || t.startsWith("share")) share = true
                if (t.startsWith("remix") || t.startsWith("simpan") || t.startsWith("save") || t.startsWith("suka") || t.startsWith("like")) act = true
            }
            for (i in 0 until x.childCount) walk(x.getChild(i), d + 1)
        }
        walk(root, 0)
        return share && act
    }

    // ---------- v1.9: tekan tombol PLAY otomatis di situs stream (jwplyr.com, vidoy.asia, dll) ----------
    private val playRe = Regex("^(?:tombol )?(?:play|putar|mainkan|tonton|watch|mulai)(?: ?(?:video|button|now|sekarang|tombol|media|film|di ?sini))?$")
    private val streamHostRe = Regex("(jwplyr\\.com|vidoy\\.(asia|com)|vldey\\.mom|vldey\\.lol|vidlyx\\.lol|overfetch\\.video|dood\\w*\\.|streamtape\\.|mixdrop\\.|filemoon\\.|streamwish\\.|vidhide\\.|voe\\.sx|upstream\\.)", RegexOption.IGNORE_CASE)
    private var playAt = 0L
    private var playClicks = 0
    private var playPage = ""

    /** Bila halaman stream terbuka dan ada tombol play yang TERLIHAT di layar: tekan otomatis, lalu semua alat memindai link video. */
    private fun autoPlay(root: AccessibilityNodeInfo, pkg: String) {
        if (!Repo.prefs().getBoolean("autoPlay", true)) return
        val pg = Resolver.lastPage
        if (pg.isEmpty() || System.currentTimeMillis() - Resolver.lastPageAt > 600_000L || !streamHostRe.containsMatchIn(pg)) return
        val now = SystemClock.uptimeMillis()
        if (now - playAt < 3000) return
        if (pg != playPage) { playPage = pg; playClicks = 0 }
        if (playClicks >= 4) return
        var target: AccessibilityNodeInfo? = null
        val cnt = IntArray(1)
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || target != null || d > 30 || cnt[0]++ > 1500) return
            try {
                if (n.isVisibleToUser) {
                    for (t0 in listOf(n.contentDescription?.toString(), n.text?.toString())) {
                        val t = t0?.trim()?.lowercase() ?: continue
                        if (t.length in 3..28 && playRe.matches(t)) { target = n; return }
                    }
                }
            } catch (e: Exception) { }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(root, 0)
        val tg = target ?: return
        playAt = now; playClicks++
        var done = false
        try {
            var c: AccessibilityNodeInfo? = tg; var d = 0
            while (c != null && d < 5 && !done) { if (c.isClickable) done = c.performAction(AccessibilityNodeInfo.ACTION_CLICK); c = c.parent; d++ }
        } catch (e: Exception) { }
        if (!done) try {
            val r = android.graphics.Rect(); tg.getBoundsInScreen(r)
            val path = android.graphics.Path(); path.moveTo(r.exactCenterX(), r.exactCenterY())
            val g = android.accessibilityservice.GestureDescription.Builder()
                .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 60)).build()
            dispatchGesture(g, null, null)
        } catch (e: Exception) { }
        val host = try { android.net.Uri.parse(pg).host ?: "web" } catch (e: Exception) { "web" }
        Resolver.diag = "Situs video: tombol play ditekan otomatis, memindai link…"
        if (SiteSettings.scanHost(host)) AutoScan.onPlay("web:$host", true)
    }

    // v1.10: saat x.com (dan subdomain) dibuka/di-scroll di browser, pindai ulang halaman tiap ~10 dtk
    private val xRe = Regex("^https?://(?:[\\w-]+\\.)?(?:x|twitter)\\.com(?:/|$)", RegexOption.IGNORE_CASE)
    private var xAt = 0L
    private fun xTick() {
        val pg = Resolver.lastPage
        if (pg.isEmpty() || !xRe.containsMatchIn(pg) || Resolver.xStatusId(pg) == null || System.currentTimeMillis() - Resolver.lastPageAt > 600_000L) return
        val now = SystemClock.uptimeMillis()
        if (now - xAt < 10_000) return
        xAt = now
        Resolver.rescan(pg, null, "Aksesibilitas (halaman X)")
    }

    private val addrRe = Regex("^[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(/\\S*)?$")
    private val fileExts = setOf("pdf", "png", "jpg", "jpeg", "gif", "webp", "mp4", "mp3", "mkv", "avi", "mov", "m4a", "wav", "flac", "txt", "zip", "rar", "apk",
        "doc", "docx", "xls", "xlsx", "ppt", "pptx", "json", "xml", "log", "csv", "kt", "java", "js", "css", "html", "htm", "php", "py", "srt")
    /** Bukan nama file / nomor versi: label pertama tidak boleh hanya angka, TLD bukan ekstensi file. */
    private fun looksLikeSite(t: String): Boolean {
        if (t.startsWith("http", true)) return true
        val host = t.substringBefore('/')
        val first = host.substringBefore('.')
        if (first.isEmpty() || first.all { it.isDigit() }) return false
        return host.substringAfterLast('.').lowercase() !in fileExts
    }
    private var genBarTxt = ""
    private var genBarAt = 0L
    private fun genericBar(t: String) {
        val now = SystemClock.uptimeMillis()
        if (t == genBarTxt && now - genBarAt < 4000L) return
        genBarTxt = t; genBarAt = now
        handleBar(t)
    }

    private fun handleBar(t: String) {
        var s = t.trim()
        if (s.contains(' ')) return
        if (!s.startsWith("http")) {
            if (hostRe.matches(s)) s = "https://$s" else return
        }
        // v1.61: pindah situs di browser (alamat host berubah) -> buang cache situs lama
        val hh = try { android.net.Uri.parse(s).host ?: "" } catch (e: Exception) { "" }
        if (hh.isNotEmpty() && Resolver.siteKey(hh) != Resolver.siteKey(Resolver.activeHost)) {
            if (Resolver.activeHost.isNotEmpty()) Resolver.beginScope(Resolver.activePkg.ifEmpty { fgPkg }, hh) else Resolver.activeHost = hh
        }
        Resolver.lastPage = s
        Resolver.diag = "Sedang scan: " + Resolver.shortAddr(s)
        Resolver.submit(s, null, false, "Aksesibilitas (bar alamat)")
        Resolver.sniff(s)
    }

    private fun scan(n: AccessibilityNodeInfo?, d: Int, cnt: IntArray, force: Boolean, src: String): Int {
        if (n == null || d > 30 || cnt[0]++ > 1200) return 0
        var f = 0
        // v1.11: di aplikasi YouTube (mode normal) tautan YouTube lain di layar (komentar, deskripsi, rekomendasi) TIDAK dipindai otomatis:
        // fokus hanya pada video yang sudah dibuka. Mode agresif / tombol manual tetap memindai semuanya.
        val ytOnly = curPkg.contains("youtube", true) && !Scan.aggr() && !force
        if (ytOnly) return 0   // v1.12: di aplikasi YouTube (otomatis, mode normal) tautan di layar tidak dipindai sama sekali
        // v1.3: bar alamat browser mana pun (id berisi url/address/omnibox), mis. browser 1DM+, Kiwi, Via, dll
        val vid = n.viewIdResourceName?.lowercase()
        if (vid != null && (vid.contains("url") || vid.contains("address") || vid.contains("omnibox") || vid.contains("location_bar") || vid.contains("search_box_text") || vid.contains("toolbar_text"))) n.text?.toString()?.let { handleBar(it) }
        // v1.190: bar alamat browser APA PUN (ID view tidak dikenal): EditText, atau teks alamat di 22% teratas layar pada browser
        if (!curPkg.contains("youtube", true)) {
            val tx = n.text?.toString()?.trim()
            if (tx != null && tx.length in 4..200 && !tx.contains(' ') && (addrRe.matches(tx) || (tx.startsWith("http", true) && !tx.contains('\n'))) && looksLikeSite(tx)) {
                val isEdit = n.className?.toString()?.endsWith("EditText") == true && !n.isPassword
                var ok = isEdit
                if (!ok && isBrowserPkg(curPkg)) {
                    val rr = android.graphics.Rect(); try { n.getBoundsInScreen(rr) } catch (e: Exception) { }
                    ok = rr.height() > 0 && rr.top >= 0 && rr.top < resources.displayMetrics.heightPixels * 0.22
                }
                if (ok) genericBar(tx)
            }
        }
        for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
            if (t != null && t.contains("http")) {
                urlRe.findAll(t).forEach { m -> val x = m.value.trimEnd('.', ',', ';', ')'); if (ytOnly && Resolver.ytRe.containsMatchIn(x)) return@forEach; f++; Resolver.submit(x, null, force, src) }
            }
        }
        for (t in listOf(n.text?.toString(), n.contentDescription?.toString())) {
            if (t != null && !t.contains("http") && t.length > 8) {
                bareRe.findAll(t).forEach { m -> val x = "https://" + m.value.trimEnd('.', ',', ';', ')'); if (ytOnly && Resolver.ytRe.containsMatchIn(x)) return@forEach; f++; Resolver.submit(x, null, force, src) }
            }
        }
        for (i in 0 until n.childCount) f += scan(n.getChild(i), d + 1, cnt, force, src)
        return f
    }

    override fun onInterrupt() {}

    /** Service terlepas sementara (VPN/root/sistem): hanya kosongkan referensi; izin di Settings tetap dianggap aktif. */
    override fun onUnbind(intent: android.content.Intent?): Boolean {
        inst = null
        try { stopForeground(true) } catch (e: Exception) { }
        return super.onUnbind(intent)
    }
}
