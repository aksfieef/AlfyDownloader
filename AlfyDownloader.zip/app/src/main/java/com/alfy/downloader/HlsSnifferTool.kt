package com.alfy.downloader

import android.os.Handler
import android.os.Looper
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Tool Tier 2 "HLS Sniffer": menyadap request WebView (shouldInterceptRequest); URL berakhiran .m3u8 (HLS) atau .mpd (DASH)
 * otomatis masuk daftar download. Dipakai pasif oleh Browser Alfy / WebView pemindai ([onRequest]) dan aktif lewat rantai tool ([grab]).
 */
object HlsSnifferTool {
    @Volatile var hits = 0
    @Volatile var last = ""
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val adRe = Regex("doubleclick|googlesyndication|googleads|imasdk|adservice|/vast|adsystem|pubads|adnxs|popads|histats", RegexOption.IGNORE_CASE)

    /** Status singkat untuk panel tool. */
    fun status(): String = if (hits > 0) "✓ $hits stream tertangkap • $last" else "⏳ siaga menyadap .m3u8/.mpd"

    /** "m3u8" / "mpd" bila URL (tanpa query) berakhiran ekstensi itu, selain itu "". */
    fun kindOf(u: String): String {
        val p = u.substringBefore('#').substringBefore('?').lowercase()
        return when { p.endsWith(".m3u8") -> "m3u8"; p.endsWith(".mpd") -> "mpd"; else -> "" }
    }

    fun clear() { seen.clear(); jwSeen.clear() }
    private val jwSeen = ConcurrentHashMap.newKeySet<String>()

    /** Kandidat dari player probe JWPlayer: manifest (.m3u8/.mpd) lewat jalur onRequest (dedup + noteHls), media langsung diuji resolver (addMediaChecked) - tidak dianggap valid sebelum lolos uji. */
    private fun jwCandidate(u: String, ref: String?, page: String, found: AtomicInteger) {
        if (!u.startsWith("http") || adRe.containsMatchIn(u) || WebTool.isAd(u, page)) return
        if (kindOf(u).isNotEmpty()) { if (onRequest(u, ref ?: page, page, "HLS Sniffer", Resolver.UA)) found.incrementAndGet(); return }
        if (!jwSeen.add(u) || seen.contains(u)) return
        Thread {
            ToolLog.tl.set("HLS Sniffer")
            try { if (Resolver.addMediaChecked(u, ref ?: page, "", false)) found.incrementAndGet() } catch (e: Throwable) { } finally { ToolLog.tl.remove() }
        }.apply { isDaemon = true; start() }
    }

    class JwBridge(val page: String, val found: AtomicInteger) {
        @android.webkit.JavascriptInterface fun r(u: String) { HlsSnifferTool.jwCandidate(u, page, page, found) }
        @android.webkit.JavascriptInterface fun rr(u: String, ref: String?) { HlsSnifferTool.jwCandidate(u, ref?.takeIf { it.startsWith("http") } ?: page, page, found) }
        @android.webkit.JavascriptInterface fun v() { }
    }

    /** Dipanggil dari shouldInterceptRequest. true = URL baru yang diterima sebagai stream. */
    fun onRequest(u: String, referer: String?, page: String?, src: String = "HLS Sniffer", ua: String? = null): Boolean {
        val k = kindOf(u)
        if (k == "m3u8" && u.startsWith("http") && !adRe.containsMatchIn(u)) {
            try { android.webkit.CookieManager.getInstance().flush() } catch (e: Throwable) { }
            Resolver.noteHls(u, referer ?: page, ua)
        }
        if (k.isEmpty() || !u.startsWith("http") || adRe.containsMatchIn(u)) return false
        if (!Tool.on("HLS Sniffer") || Block.isBlocked(u)) return false
        if (!seen.add(u)) return false
        hits++; last = k + " • " + u.substringAfter("://").substringBefore('/').take(28)
        val ref = referer ?: page
        ToolLog.side("HLS Sniffer", "✓ $hits stream ($k)")
        if (k == "m3u8") Resolver.submitMedia(u, ref, src)
        else Repo.addCandidates(listOf(Candidate(
            key = "SNF" + u.take(150), url = u, title = Resolver.nameOf(u).ifBlank { "Stream DASH" }, kind = Kind.YTDLP,
            isAudio = false, ext = "mp4", size = -1, quality = "DASH (.mpd)", duration = 0, formatSel = null,
            previewUrl = u, referer = ref, source = src)))
        return true
    }

    /** Tool rantai: muat halaman di WebView tersembunyi, sadap request .m3u8/.mpd. null = berhasil. */
    fun grab(page: String): String? {
        val found = AtomicInteger(0)
        val h = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        h.post {
            try {
                val w = WebView(Repo.app)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.mediaPlaybackRequiresUserGesture = false
                w.settings.userAgentString = Resolver.UA
                try { android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(w, true) } catch (e: Throwable) { }
                try { w.addJavascriptInterface(JwBridge(page, found), "AlfyJ") } catch (e: Throwable) { }
                w.webViewClient = object : WebViewClient() {
                    // klik tombol play tidak boleh melempar WebView ke situs iklan
                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = request.isForMainFrame
                    override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                        val u = request.url.toString()
                        if (!request.isForMainFrame && WebTool.isAd(u, page)) return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
                        if (onRequest(u, request.requestHeaders?.get("Referer"), page, "HLS Sniffer", Resolver.UA)) found.incrementAndGet()
                        return null
                    }
                    override fun onPageFinished(view: WebView, url: String) {
                        try { view.evaluateJavascript(MoreTools.JW_PROBE_JS, null) } catch (e: Throwable) { }   // player probe JWPlayer (polling terbatas)
                        // lepas sandbox iframe pemutar + 1x klik tengah layar bila video belum memutar
                        view.evaluateJavascript("""(function(){try{document.querySelectorAll('iframe').forEach(function(f){try{if(f.hasAttribute('sandbox')){var s=f.src;f.removeAttribute('sandbox');if(s)f.src=s;}}catch(e){}});}catch(e){}
setTimeout(function(){try{var v=document.querySelector('video');if(!v||v.paused){var e=document.elementFromPoint(innerWidth/2,innerHeight/2);if(e)e.click();}}catch(x){}},2500);})();""", null)
                        view.postDelayed({ try { view.evaluateJavascript("(function(){var v=document.querySelector('video');if(v){v.muted=true;try{v.play();}catch(e){}}})();", null) } catch (e: Throwable) { } }, 3000)
                        view.evaluateJavascript("(function(){var t=0;var i=setInterval(function(){var v=document.querySelector('video');" +
                            "if(v){v.muted=true;try{v.play();}catch(e){}}" +
                            "var b=document.querySelector('.jw-icon-display,.jw-display-icon-container,.vjs-big-play-button,.plyr__control--overlaid,.fp-play');" +
                            "if(b&&t%4==0){try{b.click();}catch(e){}}if(++t>40)clearInterval(i);},500);})();", null)
                    }
                }
                w.loadUrl(page)
            } catch (e: Throwable) { }
        }
        var waited = 0
        var lastAt = -1
        var lastCnt = 0
        while (waited < ScanLimit.cap(9_000)) {   // dalam anggaran total scan 10 dtk
            val c = found.get()
            if (c > lastCnt) { lastCnt = c; lastAt = waited }   // sumber baru (mis. master playlist / kualitas lebih baik) memperpanjang pemantauan
            if (lastAt >= 0 && waited - lastAt >= 2500) break
            try { Thread.sleep(250) } catch (e: InterruptedException) { break }
            waited += 250
        }
        h.post { WvClean.kill(wv); wv = null }
        return if (found.get() > 0) null else "tidak ada request .m3u8/.mpd"
    }
}
