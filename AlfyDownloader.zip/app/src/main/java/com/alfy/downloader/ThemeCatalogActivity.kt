package com.alfy.downloader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.alfy.downloader.extras.AlfyHttp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request

/** Halaman layar penuh katalog tema: grid 2 kolom, status unduh per tema, switch otomatis, tombol file HP. */
class ThemeCatalogActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AlfyTheme { Page() } }
    }

    private fun done(ok: Boolean, onOk: () -> Unit) = runOnUiThread {
        if (ok) { Wallpaper.reloadTabs(); onOk(); Toast.makeText(this, "Tema terpasang", Toast.LENGTH_SHORT).show() }
        else Toast.makeText(this, "Gagal mengunduh tema: " + Wallpaper.lastError.ifBlank { "cek koneksi" }, Toast.LENGTH_LONG).show()
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun Page() {
        var items by remember { mutableStateOf<List<Wallpaper.ThemeItem>?>(null) }
        var current by remember { mutableStateOf(Repo.prefs().getString("themeCurrentId", "") ?: "") }
        var loading by remember { mutableStateOf(setOf<String>()) }
        var auto by remember { mutableStateOf(AppPreferences.wallpaperAuto) }
        LaunchedEffect(Unit) { items = withContext(Dispatchers.IO) { Wallpaper.catalog() } }
        var style by remember { mutableStateOf(AppPreferences.themeStyle) }
        val pick = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val uri = res.data?.data
            if (uri != null) {
                loading = loading + "__file"
                Wallpaper.applyUri(uri) { ok -> done(ok) { current = Repo.prefs().getString("themeCurrentId", "") ?: "" }; runOnUiThread { loading = loading - "__file" } }
            }
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                TopAppBar(
                    title = { Text("Tema") },
                    navigationIcon = { TextButton(onClick = { finish() }) { Text("\u2190", color = LocalUiStyle.current.onBar) } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = LocalUiStyle.current.bar, titleContentColor = LocalUiStyle.current.onBar)
                )
            }
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Ganti Tema Otomatis (Harian)", Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
                    Switch(checked = auto, onCheckedChange = { auto = it; AppPreferences.wallpaperAuto = it })
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Gaya UI", Modifier.weight(1f), color = MaterialTheme.colorScheme.onBackground)
                    FilterChip(selected = style == "dynamic", onClick = { style = "dynamic"; Wallpaper.setStyle("dynamic") }, label = { Text("Dinamis") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = style == "transparent", onClick = { style = "transparent"; Wallpaper.setStyle("transparent") }, label = { Text("Transparan") })
                }
                Button(onClick = { pick.launch(Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI).apply { type = "image/*" }) }, enabled = "__file" !in loading, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    if ("__file" in loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    else Text("Pilih dari Galeri HP")
                }
                Spacer(Modifier.height(8.dp))
                val list = items
                if (list == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                else LazyVerticalGrid(
                    columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(list, key = { it.id }) { t ->
                        val busy = t.id in loading
                        val installed = current == t.id
                        Column(Modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface)) {
                            Preview(t.preview, Modifier.fillMaxWidth().aspectRatio(0.66f))
                            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(t.name, Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurface, maxLines = 1)
                                Box(Modifier.defaultMinSize(minWidth = 40.dp).height(36.dp).clickable(enabled = !busy && !installed) {
                                    loading = loading + t.id
                                    Wallpaper.applyUrl(t.id, t.url) { ok -> done(ok) { current = t.id }; runOnUiThread { loading = loading - t.id } }
                                }, contentAlignment = Alignment.Center) {
                                    when {
                                        busy -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                                        installed -> Text("Terpasang", color = Color(0xFF4CAF50))
                                        else -> Text("\u2B07 Pasang", color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private val pvClient: okhttp3.OkHttpClient by lazy {
        okhttp3.OkHttpClient.Builder().followRedirects(true).followSslRedirects(true)
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS).readTimeout(20, java.util.concurrent.TimeUnit.SECONDS).build()
    }
    private val pvCache = object : android.util.LruCache<String, Bitmap>(24) {}

    private fun fetchPreview(url0: String): Bitmap? {
        val url = url0.ifBlank { "https://picsum.photos/seed/alfy0/400/600" }
        pvCache.get(url)?.let { return it }
        val clients = listOf(AlfyHttp.dohClient, pvClient, AlfyHttp.client)
        for (c in clients) for (attempt in 0..1) {
            try {
                val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36").build()
                val b = c.newCall(req).execute().use { r -> if (r.isSuccessful) r.body?.bytes() else null } ?: continue
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                var ss = 1; while (o.outWidth / (ss * 2) >= 600) ss *= 2
                val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = ss })
                if (bm != null) { pvCache.put(url, bm); return bm }
            } catch (e: Throwable) { android.util.Log.w("AlfyTheme", "fetchPreview gagal: $url (${e.message})") }
        }
        return null
    }

    @Composable
    private fun Preview(url0: String, mod: Modifier) {
        val url = url0.ifBlank { "https://picsum.photos/seed/alfy0/400/600" }
        var tries by remember(url) { mutableStateOf(0) }
        var fin by remember(url, tries) { mutableStateOf(url.isBlank()) }
        val bmp by produceState<Bitmap?>(null, url, tries) {
            if (url.isBlank()) return@produceState
            value = withContext(Dispatchers.IO) { fetchPreview(url) }
            fin = true
        }
        Box(mod.background(Color(0xFF424242)).clickable(enabled = fin && bmp == null && url.isNotBlank()) { tries++ }, contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else if (!fin) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
            else Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("\uD83D\uDDBC", color = Color(0xFF9E9E9E), style = MaterialTheme.typography.headlineMedium)
                Text("Gagal memuat gambar, cek koneksi", color = Color(0xFF9E9E9E), style = MaterialTheme.typography.labelSmall)
                Text("Ketuk untuk muat ulang", color = Color(0xFF9E9E9E), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
