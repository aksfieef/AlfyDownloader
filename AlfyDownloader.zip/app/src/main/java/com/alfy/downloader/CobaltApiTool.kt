package com.alfy.downloader

import java.net.HttpURLConnection
import java.net.URL

/** Tool Tier 3 "Cobalt API": fallback universal (YouTube, TikTok, Instagram, Twitter/X, Reddit, Vimeo, SoundCloud, dll) lewat server publik Cobalt. */
object CobaltApiTool {
    private val API: String get() = AppPreferences.cobaltApiUrl

    // ---------- Daftar instance Cobalt v10 sehat (tanpa Turnstile), cache 10 menit (mirip Inst) ----------
    private const val DIRECTORY_URL = "https://cobalt.directory/api/working?type=api&turnstile=0"
    private const val BACKUP_URL = "https://instances.cobalt.best/api/instances.json"
    @Volatile private var dyn: List<String> = emptyList()
    @Volatile private var dynAt = 0L

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 4500; c.readTimeout = 6000
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            if (c.responseCode >= 400) return ""
            return c.inputStream.bufferedReader().readText()
        } finally { try { c.disconnect() } catch (e: Throwable) { } }
    }

    private fun normBase(u: String): String {
        var x = u.trim()
        if (x.isEmpty()) return ""
        if (!x.startsWith("http")) x = "https://$x"
        x = x.trimEnd('/')
        if (x.endsWith("/api/json")) x = x.removeSuffix("/api/json")
        return x
    }

    /** Kumpulkan nilai `api`/`url` dari JSON bentuk apa pun (array string, array objek, objek berisi array). */
    private fun collect(j: Any?, out: MutableList<String>, depth: Int = 0) {
        if (depth > 4 || j == null) return
        when (j) {
            is String -> if (j.startsWith("http")) out.add(j)
            is org.json.JSONArray -> for (i in 0 until j.length()) collect(j.opt(i), out, depth + 1)
            is org.json.JSONObject -> {
                val own = j.optString("api", "").ifEmpty { j.optString("url", "") }
                if (own.isNotEmpty()) { out.add(if (own.startsWith("http")) own else "https://$own") }
                else for (k in j.keys()) { val v = j.opt(k); if (v is org.json.JSONArray || v is org.json.JSONObject) collect(v, out, depth + 1) }
            }
        }
    }

    @Synchronized private fun loadDynamic() {
        if (System.currentTimeMillis() - dynAt < 600_000 && dyn.isNotEmpty()) return
        val list = ArrayList<String>()
        try {
            val raw = httpGet(DIRECTORY_URL).trim()
            if (raw.startsWith("[") || raw.startsWith("{")) {
                collect(if (raw.startsWith("[")) org.json.JSONArray(raw) else org.json.JSONObject(raw), list)
            }
        } catch (e: Throwable) { }
        if (list.isEmpty()) try {
            val a = org.json.JSONArray(httpGet(BACKUP_URL))
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                if (!o.optBoolean("online", false)) continue
                val info = o.optJSONObject("info")
                if (o.optBoolean("turnstile", false) || o.optBoolean("auth", false)) continue
                if (info != null && (info.optBoolean("turnstile", false) || info.optBoolean("auth", false))) continue
                val ver = o.optString("version", "")
                val major = ver.substringBefore('.').toIntOrNull()
                if (major != null && major < 10) continue
                val api = o.optString("api", "").ifEmpty { o.optString("url", "") }
                if (api.isEmpty()) continue
                list.add(if (api.startsWith("http")) api else o.optString("protocol", "https") + "://" + api)
            }
        } catch (e: Throwable) { }
        val clean = list.map { normBase(it) }.filter { it.startsWith("http") }.distinct()
        if (clean.isNotEmpty()) { dyn = clean; dynAt = System.currentTimeMillis() }
    }

    /** Custom (jika diubah user) didahulukan; default api.cobalt.tools -> daftar dinamis. Maks 4 instance. */
    private fun instances(): List<String> {
        val custom = normBase(API)
        val isDefault = custom.isEmpty() || custom.contains("api.cobalt.tools", true)
        loadDynamic()
        val all = ArrayList<String>()
        if (!isDefault) all.add(custom)
        all.addAll(dyn)
        return all.distinct().take(4)
    }


    private fun hostOf(page: String): String = try { android.net.Uri.parse(page).host?.lowercase() ?: "" } catch (e: Exception) { "" }

    private val supported = setOf(
        "youtube.com", "youtu.be", "tiktok.com", "instagram.com", "twitter.com", "x.com",
        "reddit.com", "vimeo.com", "soundcloud.com", "facebook.com", "fb.watch", "pinterest.com",
        "twitch.tv", "streamable.com", "tumblr.com", "vk.com", "ok.ru", "bilibili.com", "dailymotion.com"
    )

    fun matches(page: String): Boolean {
        val h = hostOf(page)
        return supported.any { h == it || h.endsWith(".$it") }
    }

    private fun post(base: String, body: String): String {
        val c = URL("$base/").openConnection() as HttpURLConnection   // Cobalt v10: POST ke root instance
        try {
            c.requestMethod = "POST"; c.connectTimeout = 4500; c.readTimeout = 6000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            return stream?.bufferedReader()?.readText() ?: ""
        } finally { try { c.disconnect() } catch (e: Throwable) { } }
    }

    private fun hostShort(base: String): String = try { android.net.Uri.parse(base).host ?: base } catch (e: Exception) { base }

    /** null = berhasil, selain itu alasan gagal yang jelas. Coba maks 4 instance berurutan sampai ada yang berhasil. */
    fun fetch(page: String): String? {
        val list = instances()
        if (list.isEmpty()) return "Cobalt: daftar server kosong (tanpa internet?)"
        val body = org.json.JSONObject().put("url", page).toString()
        val fails = ArrayList<String>()
        for (base in list) {
            if (ScanLimit.stopped()) break
            val raw = try { post(base, body).trim() } catch (e: Exception) { fails.add(hostShort(base) + ": " + (e.message ?: "gagal").take(30)); continue }
            if (!raw.startsWith("{")) { fails.add(hostShort(base) + ": bukan JSON/Turnstile"); continue }   // HTML / Turnstile
            val r = try { org.json.JSONObject(raw) } catch (e: Exception) { fails.add(hostShort(base) + ": JSON rusak"); continue }
            val status = r.optString("status", "")
            if (status != "tunnel" && status != "redirect" && status != "stream" && status != "picker") {
                val em = r.optJSONObject("error")?.optString("code", "").orEmpty().ifBlank { r.optString("text", "") }
                fails.add(hostShort(base) + ": " + em.ifBlank { status.ifBlank { "ditolak" } }.take(40)); continue
            }
            val out = parse(r, status, page)
            if (out.isEmpty()) { fails.add(hostShort(base) + ": tanpa link media"); continue }
            Repo.addCandidates(out)
            return null
        }
        return "Cobalt: " + fails.joinToString(" | ").take(200).ifBlank { "semua instance gagal" }
    }

    private fun parse(r: org.json.JSONObject, status: String, page: String): List<Candidate> {
        val out = ArrayList<Candidate>()
        val fname = r.optString("filename", "")
        val title = if (fname.isNotBlank()) fname.substringBeforeLast('.') else "Cobalt " + hostOf(page)
        val fext = fname.substringAfterLast('.', "").lowercase().takeIf { it.length in 2..4 } ?: ""
        when (status) {
            "picker" -> {
                val picker = r.optJSONArray("picker") ?: org.json.JSONArray()
                for (i in 0 until minOf(picker.length(), 10)) {
                    val o = picker.optJSONObject(i) ?: continue
                    val u = o.optString("url", ""); if (u.isEmpty()) continue
                    val type = o.optString("type", "video")
                    val isImg = type == "photo" || type == "gif"
                    out.add(Candidate(key = "COBALT" + u.take(150), url = u, title = title,
                        kind = Kind.DIRECT, isAudio = false, ext = Resolver.extOf(u).ifEmpty { if (isImg) "jpg" else "mp4" },
                        size = -1, quality = type, duration = 0, formatSel = null, previewUrl = u, referer = page))
                }
                r.optString("audio", "").takeIf { it.startsWith("http") }?.let { au ->
                    out.add(Candidate(key = "COBALT" + au.take(150), url = au, title = title, kind = Kind.DIRECT, isAudio = true,
                        ext = Resolver.extOf(au).ifEmpty { "mp3" }, size = -1, quality = "audio", duration = 0, formatSel = null,
                        previewUrl = au, referer = page, audioUrl = au))
                }
            }
            else -> {   // tunnel / redirect / stream
                val u = r.optString("url", ""); if (u.isEmpty()) return out
                val isHls = Resolver.extOf(u) == "m3u8"
                val isAud = fext == "mp3" || fext == "m4a" || fext == "opus" || fext == "ogg" || fext == "wav"
                out.add(Candidate(key = "COBALT" + u.take(150), url = u, title = title,
                    kind = if (isHls) Kind.HLS else Kind.DIRECT, isAudio = isAud,
                    ext = if (isHls) "mp4" else Resolver.extOf(u).ifEmpty { fext.ifEmpty { "mp4" } },
                    size = -1, quality = if (isAud) "audio" else "-", duration = 0, formatSel = null, previewUrl = u, referer = page))
            }
        }
        return out
    }
}
