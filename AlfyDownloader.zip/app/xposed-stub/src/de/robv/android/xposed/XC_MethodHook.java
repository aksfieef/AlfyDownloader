package de.robv.android.xposed;

/** Stub kompilasi. */
public abstract class XC_MethodHook {
    public XC_MethodHook() { }
    protected void beforeHookedMethod(MethodHookParam param) throws Throwable { }
    protected void afterHookedMethod(MethodHookParam param) throws Throwable { }

    public static class MethodHookParam {
        public java.lang.reflect.Member method;
        public Object thisObject;
        public Object[] args;
        public Object getResult() { return null; }
    }

    public class Unhook {
        public void unhook() { }
    }
}
